#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- extended DSP validation (beyond the built-in self-test).

``python3 Elite2K.py --selftest`` is the fast gate that must stay green during
development.  This script is the slower, more explicit companion: it prints the
actual frequency responses and the actual streaming error magnitudes instead of
just pass/fail, so a change in filter design or block latency is visible as
numbers rather than as a single red line.

Sections
--------
1. FIR magnitude response of the high-pass / low-pass / band-pass designers at
   chosen probe frequencies.
2. Streaming continuity for every registered block: processing a signal as one
   array versus as 2400-sample chunks must produce the same samples (float32
   rounding only), which catches any block whose internal state leaks between
   calls.
3. The pulse chain (half-wave rectifier -> Schmitt trigger -> zero-crossing
   pulse) on a 440 Hz tone, checked for asymmetric rails, both trigger levels,
   and the expected ~880 pulses/s.
4. SpectralSubtractor stream alignment: whole-buffer vs chunked processing must
   line up at shift 0 exactly, and the overlap-add tail must not be truncated
   or zero-padded (the historical defect this section guards against).

Exit status is 0 when every check passes, 1 otherwise.
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np                                     # noqa: E402

from elite2k.dsp import blocks as B                    # noqa: E402

RATE = 48000.0
_FAILURES = []


def note(msg: str) -> None:
    print(msg)


def verdict(name: str, ok: bool, detail: str) -> None:
    print("  %-10s %s" % ("[%s]" % ("OK" if ok else "FAIL"), detail))
    if not ok:
        _FAILURES.append("%s: %s" % (name, detail))


def mag_db(taps, freq: float, rate: float = RATE) -> float:
    """Magnitude of an FIR at ``freq`` in dB, zero-padded to 64k points."""
    n = 1 << 16
    H = np.fft.rfft(taps, n)
    f = np.fft.rfftfreq(n, 1.0 / rate)
    i = int(np.argmin(np.abs(f - freq)))
    return float(20.0 * np.log10(max(abs(H[i]), 1e-12)))


# ---------------------------------------------------------------------------
#  1. FIR responses
# ---------------------------------------------------------------------------

def response_section() -> None:
    note("\n=== FIR magnitude response ===")

    def report(name, blk, probes):
        blk.set_rate(RATE)
        taps = blk._design()
        print("  %-9s taps=%d" % (name, taps.size))
        out = {}
        for f in probes:
            db = mag_db(taps, f)
            out[f] = db
            print("      %7.0f Hz : %8.2f dB" % (f, db))
        return out

    hp_bal = B.HighPass()
    hp = report("highpass", hp_bal, [50, 100, 200, 440, 1000, 4000])
    lo_cut = float(getattr(hp_bal, "_params", {}).get("cutoff", 100.0))
    verdict("highpass",
            hp[440] > -1.0 and hp[50] < -20.0,
            "%.0f Hz cutoff: 440 Hz %.2f dB, 50 Hz %.2f dB"
            % (lo_cut, hp[440], hp[50]))

    lp_bal = B.LowPass()
    lp_bal.set_param("cutoff", 2300.0)
    lp = report("lowpass", lp_bal, [100, 440, 1000, 2300, 4000, 8000])
    verdict("lowpass",
            lp[440] > -1.0 and lp[4000] < -40.0,
            "2300 Hz cutoff: 440 Hz %.2f dB, 4000 Hz %.2f dB"
            % (lp[440], lp[4000]))

    bp = report("bandpass", B.BandPass(), [100, 350, 600, 850, 2000])
    pk = max(bp, key=lambda f: bp[f])
    verdict("bandpass",
            abs(pk - 600.0) <= 250.0 and bp[100] < bp[pk] and bp[2000] < bp[pk],
            "passband peak at %.0f Hz (%.2f dB), 100 Hz %.2f dB, "
            "2000 Hz %.2f dB" % (pk, bp[pk], bp[100], bp[2000]))


# ---------------------------------------------------------------------------
#  2. Streaming continuity
# ---------------------------------------------------------------------------

def continuity_section() -> None:
    note("\n=== streaming continuity (440 Hz tone, 1 s, 2400-sample chunks) ===")
    N, CHUNK = 48000, 2400
    t = np.arange(N) / RATE
    x = (0.8 * np.sin(2 * np.pi * 440.0 * t)).astype(np.float32)

    worst_name, worst_rel = "-", 0.0
    for key in sorted(B.BLOCK_REGISTRY):
        cls = B.BLOCK_REGISTRY[key]
        a = cls()
        a.set_rate(RATE)
        whole = np.asarray(a.process(x), dtype=np.float32)
        b = cls()
        b.set_rate(RATE)
        parts = [np.asarray(b.process(x[i:i + CHUNK]), dtype=np.float32)
                 for i in range(0, N, CHUNK)]
        chunked = np.concatenate(parts) if parts else np.zeros(0, dtype=np.float32)
        n = min(whole.size, chunked.size)
        err = float(np.max(np.abs(whole[:n] - chunked[:n]))) if n else 0.0
        denom = float(np.max(np.abs(whole))) + 1e-12
        rel = err / denom
        flag = "OK" if rel < 1e-5 else "MISMATCH"
        print("  %-14s max|whole-chunked| = %.3e (rel %.2e)  %s"
              % (key, err, rel, flag))
        if rel > worst_rel:
            worst_name, worst_rel = key, rel
        if rel >= 1e-5:
            _FAILURES.append("continuity/%s rel=%.3e" % (key, rel))
    verdict("continuity", worst_rel < 1e-5,
            "worst block %s at rel %.2e across %d blocks"
            % (worst_name, worst_rel, len(B.BLOCK_REGISTRY)))


# ---------------------------------------------------------------------------
#  3. Pulse chain
# ---------------------------------------------------------------------------

def pulse_chain_section() -> None:
    note("\n=== half-wave rectifier -> Schmitt -> zero-crossing pulse ===")
    N = 2400
    t = np.arange(N) / RATE
    x = (0.8 * np.sin(2 * np.pi * 440.0 * t)).astype(np.float32)

    hv = B.HalfWaveRectifier()
    hv.set_rate(RATE)
    z = np.asarray(hv.process(x), dtype=np.float32)
    print("  hwrect min=%.3f max=%.3f  (negatives map to the floor, not 0)"
          % (float(z.min()), float(z.max())))
    verdict("hwrect",
            float(z.min()) < 0.0 and float(z.max()) > 0.5,
            "asymmetric rails min=%.3f max=%.3f" % (float(z.min()), float(z.max())))

    sc = B.Schmitt()
    sc.set_rate(RATE)
    q = np.asarray(sc.process(z), dtype=np.float32)
    levels = sorted(set(np.round(np.unique(q), 3).tolist()))
    print("  schmitt levels=%s edges=%d" % (levels, sc._edges))
    verdict("schmitt",
            levels == [-0.5, 0.5] and sc._edges > 0,
            "levels=%s edges=%d" % (levels, sc._edges))

    zc = B.ZeroCrossPulse()
    zc.set_rate(RATE)
    zc.process(q)
    rate_hz = zc._pulses / (N / RATE)
    print("  zcp pulses=%d over %.1f ms -> %.0f pulses/s"
          % (zc._pulses, 1000.0 * N / RATE, rate_hz))
    verdict("zcp",
            abs(rate_hz - 880.0) < 40.0,
            "%.0f pulses/s (expect ~880 for a 440 Hz tone)" % rate_hz)


# ---------------------------------------------------------------------------
#  4. SpectralSubtractor alignment
# ---------------------------------------------------------------------------

def spectral_alignment_section() -> None:
    note("\n=== SpectralSubtractor stream alignment (whole vs chunked) ===")
    N = 48000
    rng = np.random.default_rng(7)
    t = np.arange(N) / RATE
    noise = (0.02 * rng.standard_normal(N)).astype(np.float32)
    speech = np.zeros(N, dtype=np.float32)
    speech[12000:36000] = (0.5 * np.sin(2 * np.pi * 300.0 * t[12000:36000])
                           ).astype(np.float32)
    x = (noise + speech).astype(np.float32)

    a = B.SpectralSubtractor()
    a.set_rate(RATE)
    whole = np.asarray(a.process(x), dtype=np.float32)
    b = B.SpectralSubtractor()
    b.set_rate(RATE)
    chunked = np.concatenate([np.asarray(b.process(x[i:i + 2400]), dtype=np.float32)
                              for i in range(0, N, 2400)])

    print("  len whole=%d chunked=%d" % (whole.size, chunked.size))
    shift0 = float(np.max(np.abs(whole - chunked))) if whole.size == chunked.size else float("inf")
    grid = []
    for shift in range(0, 900, 128):
        if shift == 0:
            d = shift0
        else:
            d = float(np.max(np.abs(whole[:-shift] - chunked[shift:])))
        grid.append((shift, d))
        print("      shift=%3d  max diff = %.3e" % (shift, d))
    worst_off = max(d for s, d in grid if s > 0)
    print("  whole   peak=%.4f rms=%.4f" % (float(np.max(np.abs(whole))),
                                            float(np.sqrt(np.mean(whole ** 2)))))
    print("  chunked peak=%.4f rms=%.4f" % (float(np.max(np.abs(chunked))),
                                            float(np.sqrt(np.mean(chunked ** 2)))))
    verdict("spectral", shift0 == 0.0 and worst_off > 0.0,
            "shift-0 diff %.3e, best non-zero shift %.3e (alignment unambiguous)"
            % (shift0, worst_off))
    verdict("spectral-tail",
            float(np.max(np.abs(whole[-600:]))) > 0.0,
            "tail last 600 samples max=%.3e (overlap-add tail retained)"
            % float(np.max(np.abs(whole[-600:]))))


# ---------------------------------------------------------------------------

def run() -> int:
    print("Elite2K extended DSP validation -- numpy %s, %.0f Hz"
          % (np.__version__, RATE))
    response_section()
    continuity_section()
    pulse_chain_section()
    spectral_alignment_section()
    print("\n" + "=" * 62)
    if _FAILURES:
        print("  %d check(s) FAILED" % len(_FAILURES))
        for f in _FAILURES:
            print("    - %s" % f)
        print("=" * 62)
        return 1
    print("  all extended checks passed")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    raise SystemExit(run())

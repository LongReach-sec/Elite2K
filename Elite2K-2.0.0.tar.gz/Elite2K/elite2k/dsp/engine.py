#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Elite2K -- streaming DSP engine.

The engine owns a worker thread that pulls audio-rate frames from a source,
pushes them through the (user-orderable) block chain, rate-converts the
resulting drive waveform up to the configured IQ rate and hands complex
base-band frames to the selected output back-end.  It publishes a
lock-protected snapshot (metrics + spectra) that the GUI polls.
"""

from __future__ import annotations

import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import numpy as np

from .. import config
from .blocks import (BLOCK_REGISTRY, Block, default_order, make_block)
from ..backend import sinks as sink_mod
from ..backend import sources as source_mod


# ---------------------------------------------------------------------------
#  Stateful linear resampler (rate conversion with phase continuity)
# ---------------------------------------------------------------------------

class LinearResampler:
    """Streaming fractional resampler (phase-continuous linear interpolation).

    The step is derived continuously as ``rate_in / rate_out``, so any IQ rate
    in ``[MIN_IQ_RATE, MAX_IQ_RATE]`` is reachable; 48 kHz -> 2 MS/s resolves
    to the exact ratio 125/3, which keeps pulse timing crisp.  A fractional
    sample position and the previous sample are carried across calls so
    consecutive chunks join without a phase discontinuity.  When down-
    sampling it first applies a boxcar anti-alias average.
    """

    def __init__(self) -> None:
        self._t = 0.0
        self._prev = 0.0

    def reset(self) -> None:
        self._t = 0.0
        self._prev = 0.0

    def process(self, x: np.ndarray, rate_in: float, rate_out: float) -> np.ndarray:
        if x.size == 0 or rate_in <= 0 or rate_out <= 0:
            return np.zeros(0, dtype=np.float32)
        step = rate_in / rate_out
        if step > 1.0:
            # anti-alias: boxcar pre-filter of length ~ step
            k = int(max(1, round(step)))
            if k > 1:
                c = np.cumsum(np.concatenate(([0.0], x.astype(np.float64))))
                sm = (c[k:] - c[:-k]) / k
                x = sm.astype(np.float32)
                step = 1.0                       # decimation already applied
        n = x.size
        out = []
        t = self._t
        prev = self._prev
        while t < n:
            i = int(t)
            frac = t - i
            if i <= 0:
                v = prev * (1.0 - frac) + float(x[0]) * frac
            else:
                v = float(x[i - 1]) * (1.0 - frac) + float(x[min(i, n - 1)]) * frac
            out.append(v)
            t += step
        self._t = t - n
        self._prev = float(x[-1])
        if not out:
            return np.zeros(0, dtype=np.float32)
        return np.asarray(out, dtype=np.float32)


# ---------------------------------------------------------------------------
#  Live metrics
# ---------------------------------------------------------------------------

@dataclass
class Metrics:
    running: bool = False
    chunks: int = 0
    audio_rms: float = 0.0
    audio_peak: float = 0.0
    drive_rms: float = 0.0
    drive_duty: float = 0.0
    zcr_hz: float = 0.0
    pulses_session: int = 0
    iq_rms: float = 0.0
    iq_peak: float = 0.0
    crest_db: float = 0.0
    throughput_ksps: float = 0.0
    working_rate: float = 0.0
    iq_samples: int = 0
    elapsed_s: float = 0.0
    energy_per_pulse_mj: float = 0.0
    peak_power_w: float = 0.0
    error: str = ""


# ---------------------------------------------------------------------------
#  Engine
# ---------------------------------------------------------------------------

class Engine:
    WATERFALL_ROWS = 240

    def __init__(self, profile: config.AppProfile,
                 on_log: Optional[Callable[[str], None]] = None,
                 on_source_done: Optional[Callable[[], None]] = None):
        self.profile = profile
        self._log_cb = on_log
        self._done_cb = on_source_done

        self.chunk = 2400                       # 50 ms at 48 kHz
        self._blocks: Dict[str, Block] = {}
        self._order: List[str] = []
        self._enabled: Dict[str, bool] = {}
        self._lock = threading.RLock()
        self._struct_generation = 0

        self.source: source_mod.Source = source_mod.SilenceSource()
        self._resampler = LinearResampler()
        self.sink: Optional[sink_mod.Sink] = None
        self.sink_note = ""

        self._thread: Optional[threading.Thread] = None
        self._stop_evt = threading.Event()
        self._running = False
        self._paused = False

        self.metrics = Metrics()
        self._spectrum = np.zeros(1, dtype=np.float32)
        self._spectrum_db = np.zeros(1, dtype=np.float32)
        self._spectrum_rate = 0.0
        self._scope = np.zeros(256, dtype=np.float32)
        self._waterfall: deque = deque(maxlen=self.WATERFALL_ROWS)

        self._sps_window: deque = deque(maxlen=10)
        self._t_start = 0.0
        self._pulses_base = 0

        self._build_chain()
        self._apply_source()

    # -- logging ------------------------------------------------------------

    def log(self, msg: str) -> None:
        if self._log_cb:
            try:
                self._log_cb(msg)
            except Exception:
                pass

    # -- chain construction -------------------------------------------------

    def _build_chain(self) -> None:
        with self._lock:
            order = list(self.profile.chain.order or default_order())
            for k in default_order():
                if k not in order:
                    order.append(k)
            self._order = [k for k in order if k in BLOCK_REGISTRY]
            self._blocks = {k: make_block(k) for k in self._order}
            for k, blk in self._blocks.items():
                blk.enabled = bool(self.profile.chain.enabled.get(k, True))
                for pname, pval in (self.profile.chain.params.get(k) or {}).items():
                    if pname in blk._params:
                        blk.set_param(pname, pval)
                blk.set_rate(config.AUDIO_RATE)
            self._enabled = {k: self._blocks[k].enabled for k in self._order}
            self._struct_generation += 1

    def apply_profile(self, profile: config.AppProfile) -> None:
        self.profile = profile
        self._build_chain()
        self._apply_source()

    # -- source management --------------------------------------------------

    def _apply_source(self) -> None:
        kind = self.profile.source.kind
        if kind == "tts":
            # TTS is pushed explicitly via set_tts_buffer(); until then, silent.
            self.source = source_mod.SilenceSource()
        else:
            self.source = source_mod.make_source(
                kind, config.AUDIO_RATE,
                tone_hz=self.profile.source.tone_hz)
        self._resampler.reset()

    def set_tts_buffer(self, samples: np.ndarray, loop: bool = False,
                       label: str = "tts") -> None:
        src = source_mod.BufferSource(np.asarray(samples, dtype=np.float32),
                                      loop=loop)
        with self._lock:
            self.source = src
        self._resampler.reset()
        self._pulses_base = self._pulses_total()
        self.log(f"source: {label} ({samples.size / config.AUDIO_RATE:.2f}s, "
                 f"{'loop' if loop else 'once'})")

    def _pulses_total(self) -> int:
        with self._lock:
            total = 0
            for blk in self._blocks.values():
                total += int(getattr(blk, "_pulses", 0))
            return total

    # -- block manipulation (called from the GUI thread) --------------------

    def set_block_enabled(self, key: str, enabled: bool) -> None:
        with self._lock:
            if key in self._blocks:
                self._blocks[key].enabled = bool(enabled)
                self._enabled[key] = bool(enabled)
                self._struct_generation += 1

    def set_block_param(self, key: str, name: str, value: float) -> None:
        with self._lock:
            blk = self._blocks.get(key)
            if blk is not None and name in blk._params:
                blk.set_param(name, value)

    def move_block(self, key: str, delta: int) -> None:
        with self._lock:
            if key not in self._order:
                return
            i = self._order.index(key)
            j = max(0, min(len(self._order) - 1, i + delta))
            if i == j:
                return
            self._order.insert(j, self._order.pop(i))
            self.profile.chain.order = list(self._order)
            self._struct_generation += 1

    def block_chain(self) -> List[Block]:
        with self._lock:
            return [self._blocks[k] for k in self._order]

    # -- lifecycle ----------------------------------------------------------

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            return
        self.sink, self.sink_note = sink_mod.open_sink(self.profile)
        if self.sink_note:
            self.log(f"backend: {self.sink.info()} -- {self.sink_note}")
        else:
            self.log(f"backend: {self.sink.info()}")
        with self._lock:
            for blk in self._blocks.values():
                blk.reset()
            self.source.reset()
        self._resampler.reset()
        self._stop_evt.clear()
        self._running = True
        self.metrics = Metrics(running=True)
        self._t_start = time.monotonic()
        self._pulses_base = 0
        self._spectrum = np.zeros(1, dtype=np.float32)
        self._spectrum_db = np.zeros(1, dtype=np.float32)
        self._waterfall.clear()
        self._thread = threading.Thread(target=self._run, name="elite2k-dsp",
                                        daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if not self._running:
            return
        self._stop_evt.set()
        if self._thread is not None:
            self._thread.join(timeout=3.0)
            self._thread = None
        self._running = False
        self.metrics.running = False
        if self.sink is not None:
            try:
                self.sink.close()
            except Exception:
                pass
        self.log("stopped")

    def toggle_pause(self) -> bool:
        self._paused = not self._paused
        return self._paused

    # -- worker -------------------------------------------------------------

    def _run(self) -> None:
        prof = self.profile
        try:
            while not self._stop_evt.is_set():
                t0 = time.monotonic()
                if self._paused:
                    time.sleep(0.05)
                    continue
                self._process_chunk()
                if prof.realtime:
                    target = self.chunk / config.AUDIO_RATE
                    dt = time.monotonic() - t0
                    if dt < target:
                        time.sleep(target - dt)
                else:
                    # yield so a fast simulation cannot starve the GUI thread
                    time.sleep(0.001)
        except Exception as exc:                      # pragma: no cover
            self.metrics.error = str(exc)
            self.log(f"ERROR: {exc}")
        finally:
            self.metrics.running = False

    def _process_chunk(self) -> None:
        prof = self.profile
        with self._lock:
            source = self.source
            chain = [self._blocks[k] for k in self._order if self._blocks[k].enabled]
        x = source.read(self.chunk)

        # -- audio-domain statistics (input) --------------------------------
        audio_rms = float(np.sqrt(np.mean(x.astype(np.float64) ** 2) + 1e-12))
        audio_peak = float(np.max(np.abs(x))) if x.size else 0.0
        signs = np.signbit(x)
        zc = int(np.count_nonzero(signs[1:] != signs[:-1])) if x.size > 1 else 0
        zcr_hz = zc * config.AUDIO_RATE / max(1, x.size)

        # -- run the chain, tracking the working rate -----------------------
        rate = float(config.AUDIO_RATE)
        for blk in chain:
            if abs(getattr(blk, "_rate", rate) - rate) > 1e-6:
                blk.set_rate(rate)
            x = blk.process(x)
            if x.size == 0:
                x = np.zeros(0, dtype=np.float32)
                break
            rf = getattr(blk, "rate_factor", None)
            if callable(rf):
                rate *= rf()

        if x.size == 0:
            return
        drive = x.astype(np.float32, copy=False)

        # -- drive statistics ----------------------------------------------
        drive_rms = float(np.sqrt(np.mean(drive.astype(np.float64) ** 2) + 1e-12))
        drive_duty = float(np.mean(drive > 0.5)) if drive.size else 0.0

        # -- rate conversion to IQ -----------------------------------------
        iq_rate = float(prof.rf.iq_rate)
        drive_up = self._resampler.process(drive, rate, iq_rate)
        if drive_up.size == 0:
            return
        amp = float(prof.rf.tx_amplitude)
        iq = (drive_up * amp).astype(np.float32).astype(np.complex64)

        # -- output ---------------------------------------------------------
        if self.sink is not None:
            self.sink.write(iq)

        # -- spectra / scope ------------------------------------------------
        self._update_visuals(iq, drive, iq_rate)

        # -- metrics --------------------------------------------------------
        n = iq.size
        iq_rms = float(np.sqrt(np.mean(np.abs(iq) ** 2) + 1e-12))
        iq_peak = float(np.max(np.abs(iq)))
        crest = 20.0 * math.log10((iq_peak + 1e-12) / (iq_rms + 1e-12))
        self._sps_window.append(n)
        sps = float(np.mean(self._sps_window)) * max(
            1.0, 1.0 / max(1e-6, (time.monotonic() - self._t_start) /
                           max(1, self.metrics.chunks + 1)))
        pulses = self._pulses_total() - self._pulses_base
        elapsed = time.monotonic() - self._t_start
        throughput = (self.metrics.iq_samples + n) / elapsed / 1000.0 if elapsed > 0 else 0.0

        with self._lock:
            m = self.metrics
            m.running = True
            m.chunks += 1
            m.audio_rms, m.audio_peak = audio_rms, audio_peak
            m.drive_rms, m.drive_duty = drive_rms, drive_duty
            m.zcr_hz = zcr_hz
            m.pulses_session = max(0, pulses)
            m.iq_rms, m.iq_peak, m.crest_db = iq_rms, iq_peak, crest
            m.throughput_ksps = throughput
            m.working_rate = rate
            m.iq_samples += n
            m.elapsed_s = elapsed
            # nominal pulse energy -> peak power at the measured pulse width
            # (see config.PULSE_ENERGY_REFERENCE_MJ: a comparison figure, not
            # a calibrated radiometric measurement)
            pw = self._dominant_pulse_width()
            if pw > 0:
                energy_mj = float(config.PULSE_ENERGY_REFERENCE_MJ)
                m.energy_per_pulse_mj = energy_mj
                m.peak_power_w = (energy_mj * 1e-3) / (pw * 1e-6)

        # one-shot completion notification
        if getattr(source, "done", False):
            if self._done_cb:
                try:
                    self._done_cb()
                except Exception:
                    pass
            with self._lock:
                self.source = source_mod.SilenceSource()

    def _dominant_pulse_width(self) -> float:
        with self._lock:
            for key in ("zcp", "modulator"):
                blk = self._blocks.get(key)
                if blk is not None and blk.enabled:
                    return float(blk._params.get("pulse_width_us", 0.0))
        return 0.0

    def _update_visuals(self, iq: np.ndarray, drive: np.ndarray,
                        iq_rate: float) -> None:
        # scope: last 256 samples of the drive waveform (down-sampled)
        step = max(1, drive.size // 256)
        scope = drive[::step][-256:]
        # spectrum of the IQ (Hann-windowed, fft-shifted, dB)
        nfft = 1024
        if iq.size >= nfft:
            seg = iq[iq.size // 2 - nfft // 2: iq.size // 2 + nfft // 2]
            win = np.hanning(nfft).astype(np.float32)
            spec = np.fft.fftshift(np.fft.fft(seg * win))
            mag = np.abs(spec) / (nfft * 0.5)
            db = 20.0 * np.log10(mag + 1e-9)
        else:
            nfft = max(8, 1 << int(math.floor(math.log2(max(8, iq.size)))))
            win = np.hanning(nfft).astype(np.float32)
            seg = (iq[:nfft] * win) if iq.size >= nfft else \
                np.zeros(nfft, dtype=np.complex64)
            spec = np.fft.fftshift(np.fft.fft(seg))
            db = 20.0 * np.log10(np.abs(spec) / (nfft * 0.5) + 1e-9)
        db = np.clip(db, -120.0, 0.0).astype(np.float32)
        with self._lock:
            self._spectrum_db = db
            self._spectrum_rate = iq_rate
            self._scope = scope.astype(np.float32)
            self._waterfall.append(db[::max(1, db.size // 256)])

    # -- snapshot -----------------------------------------------------------

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "metrics": self.metrics,
                "spectrum_db": self._spectrum_db.copy(),
                "spectrum_rate": self._spectrum_rate,
                "scope": self._scope.copy(),
                "waterfall": list(self._waterfall),
                "sink": self.sink.info() if self.sink else "-",
                "statuses": {k: self._blocks[k].status() for k in self._order},
                "paused": self._paused,
            }
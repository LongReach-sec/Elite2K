#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- stateful, reorderable DSP block library.

Every block is a tiny streaming transform:  ``y = block.process(x)`` where
``x``/``y`` are 1-D ``float32`` NumPy arrays.  Blocks keep their own state
between calls so the engine can feed them arbitrary chunk sizes.

Two deliberate departures from the upstream OpenV2K implementation:

*   **No GNU Radio.**  All filtering/modulation is expressed directly in
    NumPy, so the tool runs on any Python with NumPy installed.
*   **Parametrised + reorderable.**  Rather than a hard-wired signal chain,
    each block advertises a machine-readable parameter schema.  The GUI and
    profile loader build the chain from that schema, so a signal path can be
    reordered, enable/disabled and tuned without touching code.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

import numpy as np

EPS = 1e-12


# ---------------------------------------------------------------------------
#  Parameter schema helpers
# ---------------------------------------------------------------------------

def P(name: str, label: str, lo: float, hi: float, default: float,
      step: float = 1.0, fmt: str = "{:.3g}") -> Dict[str, Any]:
    """Build one parameter description consumed by the GUI/profile layer."""
    return {
        "name": name, "label": label, "lo": lo, "hi": hi,
        "default": default, "step": step, "fmt": fmt,
    }


KAISER_BETA = 8.0        # ~ -80 dB stop-band, ~ 5.0*rate/taps transition
_MIN_TAPS, _MAX_TAPS = 31, 2049


def _odd_ceil(value: float) -> int:
    n = int(math.ceil(value))
    return n if n % 2 == 1 else n + 1


def _auto_taps(transition: float, rate: float) -> int:
    """Tap count that realises a ``transition``-Hz-wide transition band.

    For a Kaiser window the stop-band attenuation ``A`` and the transition
    width are related by ``M ~= (A - 8) / (2.285 * dw)`` with ``dw`` in
    rad/sample, which for beta=8 collapses to ``M ~= 5 * rate / df``.  The
    count is therefore derived from the *wanted sharpness* rather than
    hard-coded, which is what keeps a 100 Hz high-pass from eating the
    preset's 440 Hz tone on its way through.
    """
    trans = max(float(transition), 1.0)
    return max(_MIN_TAPS, min(_MAX_TAPS, _odd_ceil(5.0 * rate / trans)))


def _ideal_lowpass(cutoff: float, rate: float, ntaps: int) -> np.ndarray:
    """Kaiser-windowed ideal low-pass kernel (unnormalised)."""
    ntaps = max(3, int(ntaps) | 1)
    fc = min(max(float(cutoff), 1e-6), rate * 0.4999) / float(rate)
    m = ntaps - 1
    n = np.arange(ntaps, dtype=np.float64)
    h = 2.0 * fc * np.sinc(2.0 * fc * (n - m / 2.0))
    return h * np.kaiser(ntaps, KAISER_BETA)


def _fftconv_valid(buf: np.ndarray, taps: np.ndarray) -> np.ndarray:
    """``np.convolve(buf, taps, 'valid')`` via zero-padded FFT.

    Linear convolution through the FFT is exact here because the transform
    is zero-padded past ``len(buf) + len(taps) - 1``; there is no circular
    wrap-around.  It matters because the auto-designed kernels above can run
    to two thousand taps, where a direct convolution would dominate the
    per-chunk cost.
    """
    if taps.size < 64:
        return np.convolve(buf, taps, "valid")
    n = buf.size + taps.size - 1
    size = 1 << max(1, (n - 1).bit_length())
    spec = np.fft.rfft(buf, size) * np.fft.rfft(taps, size)
    return np.fft.irfft(spec, size)[taps.size - 1:buf.size]


# ---------------------------------------------------------------------------
#  Base block
# ---------------------------------------------------------------------------

class Block:
    """Base class for all DSP blocks."""

    key: str = "block"
    label: str = "Block"
    category: str = "signal"
    order_hint: int = 0

    def __init__(self) -> None:
        self.enabled: bool = True
        self._rate: float = 48_000.0
        self._params: Dict[str, float] = {
            spec["name"]: float(spec["default"]) for spec in self.param_specs()
        }

    # -- schema -------------------------------------------------------------

    @classmethod
    def param_specs(cls) -> List[Dict[str, Any]]:
        return []

    def param(self, name: str) -> float:
        return self._params[name]

    def set_param(self, name: str, value: float) -> None:
        self._params[name] = float(value)
        self.on_param(name, value)

    def on_param(self, name: str, value: float) -> None:
        """Hook for blocks that must recompute coefficients."""

    def set_rate(self, rate: float) -> None:
        self._rate = float(rate)
        self.on_rate(rate)

    def on_rate(self, rate: float) -> None:
        """Hook for rate-dependent blocks."""

    def reset(self) -> None:
        """Clear streaming state (called when the chain is (re)started)."""

    # -- processing ---------------------------------------------------------

    def process(self, x: np.ndarray) -> np.ndarray:      # pragma: no cover
        return x

    def status(self) -> str:
        return ""

    def describe(self) -> str:
        return self.label


# ---------------------------------------------------------------------------
#  Filtering blocks
# ---------------------------------------------------------------------------

class DcBlocker(Block):
    key, label, category, order_hint = "dcblock", "DC Blocker", "filtering", 10

    @classmethod
    def param_specs(cls):
        return [P("r", "Pole radius", 0.900, 0.9995, 0.995, 0.0005, "{:.4f}")]

    def __init__(self):
        super().__init__()
        self._state = 0.0
        self._prev = 0.0

    def reset(self):
        self._state = 0.0
        self._prev = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        r = self._params["r"]
        y = np.empty_like(x)
        s = self._state
        prev = self._prev
        # y[n] = x[n] - x[n-1] + r*y[n-1]
        for i in range(x.size):
            v = float(x[i])
            s = v - prev + r * s
            prev = v
            y[i] = s
        self._state, self._prev = s, prev
        return y


class _FIRBlock(Block):
    """Stateful linear-phase FIR with a persistent overlap tail.

    The kernel length is chosen by the subclass during :meth:`_design` (see
    :func:`_auto_taps`) instead of being nailed down at construction, so
    changing a cutoff or the block rate re-derives both the coefficients and
    the exact tail length the streaming convolution needs.
    """

    def __init__(self):
        super().__init__()
        self._taps = np.array([1.0], dtype=np.float32)
        self._tail = np.zeros(0, dtype=np.float32)
        self._rebuild()

    def reset(self):
        self._tail = np.zeros(max(0, self._taps.size - 1), dtype=np.float32)

    def _rebuild(self):
        self._taps = np.asarray(self._design(), dtype=np.float32)
        self._tail = np.zeros(max(0, self._taps.size - 1), dtype=np.float32)

    def _design(self) -> np.ndarray:
        return np.array([1.0], dtype=np.float32)

    def taps(self) -> int:
        """Current kernel length -- surfaced in the block status line."""
        return int(self._taps.size)

    def on_param(self, name, value):
        self._rebuild()

    def on_rate(self, rate):
        self._rebuild()

    def process(self, x):
        if x.size == 0:
            return x
        taps = self._taps
        if taps.size <= 1:
            return x
        buf = np.concatenate((self._tail, x.astype(np.float32, copy=False)))
        y = _fftconv_valid(buf, taps)
        # ``valid`` length is always ``len(buf) - len(taps) + 1 == len(x)``.
        self._tail = buf[-(taps.size - 1):].copy()
        if y.size != x.size:
            y = np.resize(y, x.size)
        return y.astype(np.float32, copy=False)

    def status(self):
        return "%d taps" % self._taps.size


class HighPass(_FIRBlock):
    """Linear-phase high-pass, spectrally inverted from a Kaiser low-pass.

    The kernel length is derived from the cutoff (see :func:`_auto_taps`)
    rather than fixed.  A fixed 101-tap kernel at 48 kHz has a transition
    band nearly 1.5 kHz wide, so a "100 Hz" high-pass was still down 6 dB at
    the 440 Hz dialogue tone the presets actually use -- it quietly halved
    the drive amplitude of every run.  Scaling the length with the requested
    sharpness removes that trap, and the FFT convolution keeps the cost flat.

    Gain is normalised at Nyquist (not at DC, as a low-pass would be), which
    together with the inverting tap gives an exact DC null.
    """

    key, label, category, order_hint = "highpass", "High-Pass", "filtering", 20

    @classmethod
    def param_specs(cls):
        return [P("cutoff", "Cutoff (Hz)", 20.0, 8000.0, 100.0, 10.0, "{:.0f}")]

    def _design(self):
        fc = self._params["cutoff"]
        ntaps = _auto_taps(max(0.25 * fc, 100.0), self._rate)
        lp = _ideal_lowpass(fc, self._rate, ntaps)
        lp /= max(lp.sum(), 1e-12)
        hp = -lp
        hp[ntaps // 2] += 1.0            # spectral inversion around centre tap
        n = np.arange(ntaps, dtype=np.float64)
        g = float(np.dot(hp, np.where(n.astype(int) % 2 == 0, 1.0, -1.0)))
        if abs(g) > 1e-9:
            hp /= g
        return hp


class LowPass(_FIRBlock):
    key, label, category, order_hint = "lowpass", "Low-Pass", "filtering", 30

    @classmethod
    def param_specs(cls):
        return [P("cutoff", "Cutoff (Hz)", 200.0, 20000.0, 2300.0, 50.0, "{:.0f}")]

    def _design(self):
        fc = self._params["cutoff"]
        ntaps = _auto_taps(max(0.25 * fc, 100.0), self._rate)
        h = _ideal_lowpass(fc, self._rate, ntaps)
        return h / max(h.sum(), 1e-12)   # unity DC gain


class BandPass(_FIRBlock):
    """Band-pass built as the difference of two Kaiser low-passes.

    Normalising on the *centre* frequency -- rather than trusting the two
    halves to cancel to unity -- keeps the pass-band gain at 1.0 across the
    whole tuning range, so sweeping ``center`` does not silently change the
    drive level.
    """

    key, label, category, order_hint = "bandpass", "Band-Pass (F1)", "filtering", 40

    @classmethod
    def param_specs(cls):
        return [
            P("center", "Centre (Hz)", 100.0, 8000.0, 600.0, 25.0, "{:.0f}"),
            P("width", "Width (Hz)", 50.0, 5000.0, 500.0, 25.0, "{:.0f}"),
        ]

    def _design(self):
        c = self._params["center"]
        w = max(20.0, self._params["width"])
        ntaps = _auto_taps(max(0.25 * w, 100.0), self._rate)
        hi = _ideal_lowpass(c + w / 2.0, self._rate, ntaps)
        lo = _ideal_lowpass(max(1.0, c - w / 2.0), self._rate, ntaps)
        h = hi - lo
        n = np.arange(ntaps, dtype=np.float64)
        probe = np.exp(-2j * math.pi * c * n / max(self._rate, 1.0))
        g = abs(complex(np.dot(h, probe)))
        if g > 1e-9:
            h /= g
        return h


class Notch(Block):
    key, label, category, order_hint = "notch", "Mains Notch", "filtering", 50

    @classmethod
    def param_specs(cls):
        return [
            P("freq", "Frequency (Hz)", 40.0, 70.0, 50.0, 1.0, "{:.0f}"),
            P("q", "Q factor", 1.0, 30.0, 8.0, 0.5, "{:.1f}"),
            P("harmonics", "Harmonics", 0, 4, 1, 1, "{:.0f}"),
        ]

    def __init__(self):
        super().__init__()
        self._coeffs: List[np.ndarray] = []
        self._states: List[np.ndarray] = []
        self._rebuild()

    def _rebuild(self):
        f0 = self._params["freq"]
        q = max(0.1, self._params["q"])
        nh = int(round(self._params["harmonics"]))
        self._coeffs, self._states = [], []
        for h in range(1, nh + 1):
            f = f0 * h
            if f >= self._rate / 2 * 0.95:
                break
            w0 = 2.0 * math.pi * f / self._rate
            alpha = math.sin(w0) / (2.0 * q)
            b = np.array([1.0, -2.0 * math.cos(w0), 1.0])
            a = np.array([1.0 + alpha, -2.0 * math.cos(w0), 1.0 - alpha])
            b = b / a[0]
            a = a / a[0]
            self._coeffs.append((b, a))
            self._states.append(np.zeros(2))

    def on_param(self, name, value):
        self._rebuild()

    def on_rate(self, rate):
        self._rebuild()

    def reset(self):
        self._states = [np.zeros(2) for _ in self._states]

    def process(self, x):
        if x.size == 0 or not self._coeffs:
            return x
        y = x.astype(np.float64, copy=True)
        for (b, a), z in zip(self._coeffs, self._states):
            z1, z2 = float(z[0]), float(z[1])
            out = np.empty_like(y)
            for i in range(y.size):
                v = y[i]
                o = b[0] * v + z1
                z1 = b[1] * v - a[1] * o + z2
                z2 = b[2] * v - a[2] * o
                out[i] = o
            z[0], z[1] = z1, z2
            y = out
        return y.astype(np.float32)


class PreEmphasis(Block):
    key, label, category, order_hint = "preemph", "Pre-emphasis", "filtering", 60

    @classmethod
    def param_specs(cls):
        return [P("a", "Coefficient", 0.0, 0.99, 0.95, 0.01, "{:.2f}")]

    def __init__(self):
        super().__init__()
        self._prev = 0.0

    def reset(self):
        self._prev = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        a = self._params["a"]
        buf = np.empty(x.size + 1, dtype=np.float32)
        buf[0] = self._prev
        buf[1:] = x
        y = (buf[1:] - a * buf[:-1]).astype(np.float32)
        self._prev = float(x[-1])
        return y


class DeEmphasis(Block):
    key, label, category, order_hint = "deemph", "De-emphasis", "filtering", 70

    @classmethod
    def param_specs(cls):
        return [P("a", "Pole", 0.0, 0.99, 0.5, 0.01, "{:.2f}")]

    def __init__(self):
        super().__init__()
        self._state = 0.0

    def reset(self):
        self._state = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        a = self._params["a"]
        y = np.empty_like(x)
        s = self._state
        for i in range(x.size):
            s = float(x[i]) + a * s
            y[i] = s
        self._state = s
        return y


# ---------------------------------------------------------------------------
#  Dynamics / conditioning blocks
# ---------------------------------------------------------------------------

class Agc(Block):
    """Feed-forward AGC: sample-wise RMS envelope, smoothed gain.

    Both the level detector and the gain are one-pole recursions advanced
    *per sample*, so the result depends only on the signal and the time
    constant -- never on how the engine happens to slice it into chunks.
    The previous block-wise version measured one RMS per call, which made
    the very same audio produce a different output waveform (and a
    different steady-state gain) at a 50 ms chunk size than at a 1 s one;
    that is invisible in an offline render but wrong in a streaming chain,
    and it also made the block untestable by re-chunking.

    The detector runs faster than the gain (``tc/4`` vs ``tc``) so the gain
    reacts to level changes quickly but arrives smoothly, with no audible
    pumping on the syllable rate.
    """

    key, label, category, order_hint = "agc", "AGC", "dynamics", 80

    @classmethod
    def param_specs(cls):
        return [
            P("target", "Target RMS", 0.02, 0.9, 0.30, 0.01, "{:.2f}"),
            P("tc_ms", "Time constant (ms)", 1.0, 1000.0, 50.0, 1.0, "{:.0f}"),
            P("max_gain", "Max gain (x)", 1.0, 500.0, 50.0, 1.0, "{:.0f}"),
        ]

    def __init__(self):
        super().__init__()
        self._gain = 1.0
        self._env = 0.0            # mean-square envelope

    def reset(self):
        self._gain = 1.0
        self._env = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        target = self._params["target"]
        max_gain = self._params["max_gain"]
        tc = max(1e-3, self._params["tc_ms"] / 1000.0)
        dt = 1.0 / max(self._rate, 1.0)
        a_env = math.exp(-dt / max(tc * 0.25, 1e-5))
        a_gain = math.exp(-dt / tc)
        env, gain = self._env, self._gain
        out = np.empty_like(x)
        for i in range(x.size):
            v = float(x[i])
            env = a_env * env + (1.0 - a_env) * (v * v)
            desired = min(max_gain, target / max(math.sqrt(env + EPS), EPS))
            gain = a_gain * gain + (1.0 - a_gain) * desired
            out[i] = v * gain
        self._env, self._gain = env, gain
        return out.astype(np.float32)

    def status(self):
        return f"gain {self._gain:.2f}x"


class NoiseGate(Block):
    key, label, category, order_hint = "noisegate", "Noise Gate", "dynamics", 90

    @classmethod
    def param_specs(cls):
        return [
            P("threshold_db", "Threshold (dB)", -80.0, 0.0, -30.0, 1.0, "{:.0f}"),
            P("attack_ms", "Attack (ms)", 0.1, 50.0, 2.0, 0.1, "{:.1f}"),
            P("release_ms", "Release (ms)", 5.0, 1000.0, 120.0, 5.0, "{:.0f}"),
        ]

    def __init__(self):
        super().__init__()
        self._env = 1.0

    def reset(self):
        self._env = 1.0

    def process(self, x):
        if x.size == 0:
            return x
        thr = 10.0 ** (self._params["threshold_db"] / 20.0)
        dt = 1.0 / max(self._rate, 1.0)
        atk = max(1e-5, self._params["attack_ms"] / 1000.0)
        rel = max(1e-5, self._params["release_ms"] / 1000.0)
        a_atk = math.exp(-dt / atk)
        a_rel = math.exp(-dt / rel)
        out = np.empty_like(x)
        env = self._env
        for i in range(x.size):
            level = abs(float(x[i]))
            goal = 1.0 if level >= thr else 0.0
            coeff = a_atk if goal > env else a_rel
            env = coeff * env + (1.0 - coeff) * goal
            out[i] = float(x[i]) * env
        self._env = env
        return out

    def status(self):
        return f"open {self._env * 100:.0f}%"


class EnvelopeFollower(Block):
    key, label, category, order_hint = "envfollow", "Envelope Follower", "dynamics", 100

    @classmethod
    def param_specs(cls):
        return [P("tc_ms", "Release (ms)", 0.2, 500.0, 5.0, 0.2, "{:.1f}")]

    def __init__(self):
        super().__init__()
        self._env = 0.0

    def reset(self):
        self._env = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        tc = max(1e-5, self._params["tc_ms"] / 1000.0)
        dt = 1.0 / max(self._rate, 1.0)
        a = math.exp(-dt / tc)
        out = np.empty_like(x)
        env = self._env
        for i in range(x.size):
            v = abs(float(x[i]))
            env = a * env + (1.0 - a) * v
            out[i] = env
        self._env = env
        return out


class SpectralSubtractor(Block):
    """Overlap-add spectral gate with a fixed, chunk-size-independent latency.

    A Hann-windowed STFT keeps a slowly-adapting estimate of the noise
    magnitude floor; the floor is subtracted (with a spectral floor) before
    resynthesis.

    Unlike the upstream STFT stage this one is *exactly* chunk-size
    independent, which takes three deliberate details:

    *   The overlap-add accumulator is one monotonic stream indexed by a
        global frame counter, so frame ``k`` always lands on the same
        absolute output sample no matter how the caller split the input.
    *   Samples are released only once every frame that overlaps them has
        been summed in.  The previous implementation emitted the still
        incomplete tail and zero-padded the shortfall, which slid the whole
        stream by up to one hop (256 samples) per call.
    *   The released block is divided by the exact Hann-squared overlap
        envelope.  Hann^2 at 50 % overlap is *not* constant (it ripples
        between 0.5 and 1.0), so a plain sum would leave an audible 256 Hz
        amplitude ripple on a tone.

    The price is a fixed latency of :attr:`_PRIME` samples (10.7 ms at
    48 kHz) reported through :meth:`latency`, which is the right trade for a
    live chain: no drift, no glitches, and identical output for any chunk
    size.
    """

    key, label, category, order_hint = "spectralsub", "Spectral Subtract", "dynamics", 110

    _FRAME = 512
    _HOP = 256
    _PRIME = _FRAME          # output priming == fixed latency, in samples

    @classmethod
    def param_specs(cls):
        return [
            P("reduction_db", "Reduction (dB)", 0.0, 40.0, 12.0, 1.0, "{:.0f}"),
            P("alpha", "Noise adapt", 0.50, 0.999, 0.95, 0.005, "{:.3f}"),
        ]

    def __init__(self):
        super().__init__()
        self._win = np.hanning(self._FRAME).astype(np.float32)
        w2 = self._win.astype(np.float64) ** 2
        # Exact steady-state Hann^2 overlap envelope, one period (hop) long.
        self._env = (w2[:self._HOP] + w2[self._HOP:self._FRAME]).astype(np.float32)
        self._noise: Optional[np.ndarray] = None
        self.reset()

    def reset(self):
        self._noise = None
        self._inbuf = np.zeros(0, dtype=np.float32)
        # ``_acc`` is the overlap-add stream; index 0 sits at stream position
        # ``_base``.  It is primed with _PRIME zeros so the very first block
        # can always be released at full length (pure latency, not padding).
        self._acc = np.zeros(self._PRIME, dtype=np.float32)
        self._base = -self._PRIME
        self._frames = 0
        self._emitted = -self._PRIME

    def on_rate(self, rate):
        return None

    def latency(self) -> int:
        """Fixed input -> output delay in samples (see the class docstring)."""
        return self._PRIME

    def _ready(self) -> int:
        """First stream position that is *not* yet fully overlap-added."""
        return self._frames * self._HOP

    def process(self, x):
        if x.size == 0:
            return x

        # -- analysis: one windowed frame per hop --------------------------
        self._inbuf = np.concatenate((self._inbuf, x))
        frames = []
        while self._inbuf.size >= self._FRAME:
            frame = self._inbuf[:self._FRAME]
            self._inbuf = self._inbuf[self._HOP:]
            spec = np.fft.rfft(frame * self._win)
            mag = np.abs(spec)
            if self._noise is None:
                self._noise = mag
            else:
                a = self._params["alpha"]
                self._noise = a * self._noise + (1.0 - a) * np.minimum(mag, self._noise)
            red = self._params["reduction_db"]
            if red > 0:
                gain = np.maximum(mag - self._noise * (10.0 ** (red / 20.0)), 0.0) \
                    / np.maximum(mag, EPS)
            else:
                gain = np.ones_like(mag)
            frames.append(np.fft.irfft(spec * gain, n=self._FRAME).astype(np.float32)
                          * self._win)

        # -- overlap-add, keyed to absolute frame indices ------------------
        if frames:
            first = self._frames
            last = first + len(frames) - 1
            need = last * self._HOP + self._FRAME - self._base
            if need > self._acc.size:
                self._acc = np.concatenate(
                    (self._acc, np.zeros(need - self._acc.size, dtype=np.float32)))
            for i, frame in enumerate(frames):
                off = (first + i) * self._HOP - self._base
                self._acc[off:off + self._FRAME] += frame
            self._frames = last + 1

        # -- release only fully summed samples ----------------------------
        avail = int(min(self._ready() - self._emitted, x.size))
        if avail < 0:
            avail = 0
        start = self._emitted - self._base
        y = self._acc[start:start + avail].copy()
        phase = self._emitted % self._HOP
        if avail:
            idx = (np.arange(avail, dtype=np.int64) + phase) % self._HOP
            y /= self._env[idx]
        self._emitted += avail
        if avail < x.size:          # unreachable for sane chunk sizes
            y = np.concatenate((y, np.zeros(x.size - avail, dtype=np.float32)))

        # -- reclaim the already-released head of the accumulator ---------
        drop = self._emitted - self._base
        if drop > 4 * self._FRAME:
            self._acc = self._acc[drop:].copy()
            self._base = self._emitted
        return y


class Decimator(Block):
    """Band-limiting / decimation stage.

    Upstream OpenV2K calls this a "decimator" but implements a 4 kHz IIR
    anti-alias low-pass that *keeps* the 48 kHz rate ("soft decimation"),
    because the only thing downstream cares about is how many spurious
    harmonic zero-crossings survive.  Elite2K defaults to that exact
    behaviour (``hard = 0``) so classic chains reproduce upstream pulse
    rates, while ``hard = 1`` additionally drops the rate by ``factor`` --
    useful when driving a narrow-band modulator where the extra samples are
    pure waste.  ``rate_factor()`` reports the resulting rate change to the
    engine, which then retunes every downstream block automatically.
    """

    key, label, category, order_hint = "decimator", "Decimator", "dynamics", 120

    @classmethod
    def param_specs(cls):
        return [
            P("cutoff", "Anti-alias (Hz)", 200.0, 12000.0, 4000.0, 50.0, "{:.0f}"),
            P("factor", "Hard factor", 1, 16, 4, 1, "{:.0f}"),
            P("hard", "Hard decimate", 0, 1, 0, 1, "{:.0f}"),
        ]

    def __init__(self):
        super().__init__()
        self._acc = np.zeros(0, dtype=np.float32)
        self._state = 0.0
        self._alpha = 0.3
        self.on_rate(self._rate)

    def on_rate(self, rate):
        fc = max(1.0, min(float(rate) * 0.45, self._params.get("cutoff", 4000.0)))
        self._alpha = 1.0 - math.exp(-2.0 * math.pi * fc / max(1.0, float(rate)))

    def on_param(self, name, value):
        self.on_rate(self._rate)

    def rate_factor(self) -> float:
        if self._params.get("hard", 0.0) < 0.5:
            return 1.0
        return 1.0 / max(1.0, round(self._params["factor"]))

    def reset(self):
        self._acc = np.zeros(0, dtype=np.float32)
        self._state = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        a, s = self._alpha, self._state
        lp = np.empty_like(x)
        for i in range(x.size):
            s += a * (float(x[i]) - s)
            lp[i] = s
        self._state = s
        if self.rate_factor() >= 1.0:
            return lp
        f = max(1, int(round(self._params["factor"])))
        buf = np.concatenate((self._acc, lp)) if self._acc.size else lp
        n_out = buf.size // f
        if n_out == 0:
            self._acc = buf.astype(np.float32)
            return np.zeros(0, dtype=np.float32)
        usable = buf[:n_out * f].reshape(n_out, f)
        self._acc = buf[n_out * f:].astype(np.float32).copy()
        return usable.mean(axis=1).astype(np.float32)


# ---------------------------------------------------------------------------
#  Non-linear conditioning blocks
# ---------------------------------------------------------------------------

class HalfWaveRectifier(Block):
    """Near-half-wave rectifier with an explicit sub-threshold floor.

    Everything at or below zero is mapped to ``floor`` instead of to 0.0.
    That detail is the difference between a working pulse train and a dead
    one: a plain ``max(x, 0)`` produces a signal that is *never* negative, so
    a following Schmitt trigger latches high forever after the first lobe and
    the zero-crossing generator downstream sees a DC level and emits nothing.
    Driving the troughs to ``-0.05`` (comfortably below the default Schmitt
    low threshold of ``-0.01``) guarantees the comparator resets on every
    cycle, so the crossing rate is preserved rather than destroyed.

    Raising ``floor`` toward zero weakens that reset; values above the
    Schmitt ``lo`` threshold will stall the chain as described above.
    """

    key, label, category, order_hint = "hwrect", "Half-Wave Rectifier", "nonlinear", 130

    @classmethod
    def param_specs(cls):
        return [
            P("floor", "Zero-level floor", -0.5, -0.0001, -0.05, 0.005, "{:.3f}"),
        ]

    def process(self, x):
        floor = np.float32(self._params["floor"])
        return np.where(x > 0.0, x, floor).astype(np.float32)


class Schmitt(Block):
    """Hysteresis comparator.

    Crucially -- and this is easy to get wrong -- the output snaps to
    ``+level`` / ``-level`` (default +/-0.5), i.e. it stays *bipolar* and
    zero-mean.  A 0/1 output would leave the downstream zero-crossing
    detector with nothing to detect: the signal would sit above its own
    reference forever and the pulse train would go silent.  Starting state is
    the low level, matching upstream, so the first rising edge always fires.
    """

    key, label, category, order_hint = "schmitt", "Schmitt Trigger", "nonlinear", 140

    @classmethod
    def param_specs(cls):
        return [
            P("hi", "High threshold", 0.0001, 0.5, 0.01, 0.0005, "{:.4f}"),
            P("lo", "Low threshold", -0.5, -0.0001, -0.01, 0.0005, "{:.4f}"),
            P("level", "Output level", 0.05, 1.0, 0.5, 0.05, "{:.2f}"),
        ]

    def __init__(self):
        super().__init__()
        self._state = -1.0
        self._edges = 0

    def reset(self):
        self._state = -1.0
        self._edges = 0

    def process(self, x):
        if x.size == 0:
            return x
        hi = self._params["hi"]
        lo = min(self._params["lo"], -abs(hi) * 0.5)
        lvl = self._params["level"]
        out = np.empty_like(x)
        s = self._state
        edges = self._edges
        for i in range(x.size):
            v = float(x[i])
            if v > hi:
                if s < 0.0:
                    edges += 1
                s = 1.0
            elif v < lo:
                if s > 0.0:
                    edges += 1
                s = -1.0
            out[i] = s * lvl
        self._state = s
        self._edges = edges
        return out

    def status(self):
        return "%d edges" % self._edges


class HilbertEnvelope(Block):
    """Syllable-rate envelope detector (upstream "Hilbert Envelope").

    Replaces the audio with its amplitude envelope minus a slow-tracking
    mean, so the result is *bipolar*: positive while the talker is active,
    negative during pauses.  The zero-crossing generator downstream then
    fires at syllable onset/offset instead of once per carrier cycle,
    which is why this block (not a wider filter) is what turns a dense
    buzz into a handful of high-energy pulses per second.

    The envelope is tracked with a rectified two-pole smoother rather than a
    block-wise FFT analytic signal: a chunked FFT would put a circular-FFT
    discontinuity at every chunk boundary, and the crossing detector would
    faithfully turn each of those artefacts into a spurious RF pulse.
    """

    key, label, category, order_hint = "hilbert", "Hilbert Envelope", "nonlinear", 150

    @classmethod
    def param_specs(cls):
        return [
            P("tc_env_ms", "Envelope (ms)", 1.0, 200.0, 20.0, 1.0, "{:.0f}"),
            P("tc_mean_ms", "Mean (ms)", 50.0, 5000.0, 500.0, 10.0, "{:.0f}"),
        ]

    def __init__(self):
        super().__init__()
        self._env = 0.0
        self._mean = 0.0

    def reset(self):
        self._env = 0.0
        self._mean = 0.0

    def process(self, x):
        if x.size == 0:
            return x
        rate = max(1.0, float(self._rate))
        a_e = 1.0 - math.exp(-1.0 / (rate * max(1e-4, self._params["tc_env_ms"] / 1000.0)))
        a_m = 1.0 - math.exp(-1.0 / (rate * max(1e-3, self._params["tc_mean_ms"] / 1000.0)))
        out = np.empty_like(x)
        env, mean = self._env, self._mean
        for i in range(x.size):
            env = a_e * abs(float(x[i])) + (1.0 - a_e) * env
            mean = a_m * env + (1.0 - a_m) * mean
            out[i] = env - mean
        self._env, self._mean = env, mean
        return out

    def status(self):
        return "env %.4f" % self._env


class ZeroCrossPulse(Block):
    """Classic OpenV2K zero-crossing pulse generator.

    Emits a fixed-width rectangular pulse every time the input crosses its
    own running DC reference, with a refractory gap so a dense signal cannot
    hold the carrier on continuously.

    Tracking the reference (rather than the literal 0.0 level) is what lets
    one block serve both halves of the upstream chain: a bipolar audio
    waveform produces one pulse per zero crossing, while the unipolar 0/1
    square wave leaving a Schmitt stage (or a half-wave rectifier) produces
    one pulse per rising *and* falling edge.
    """

    key, label, category, order_hint = "zcp", "Zero-Cross Pulse", "modulation", 200

    @classmethod
    def param_specs(cls):
        return [
            P("pulse_width_us", "Pulse width (us)", 5.0, 2000.0, 100.0, 5.0, "{:.0f}"),
            P("threshold", "Dead-band", 0.0, 0.2, 0.0, 0.001, "{:.3f}"),
        ]

    def __init__(self):
        super().__init__()
        self._plen = 5
        self._rem = 0
        self._sign = 0
        self._dc = 0.0
        self._alpha = 0.002
        self._pulses = 0

    def on_rate(self, rate):
        # 50 ms one-pole tracker: slow enough to ignore the modulation, fast
        # enough to follow a change of source level within a few chunks.
        self._alpha = min(0.2, max(1e-6, 1.0 / max(1.0, float(rate) * 0.05)))
        self._recompute()

    def on_param(self, name, value):
        self._recompute()

    def _recompute(self):
        self._plen = max(1, int(round(self._rate * self._params["pulse_width_us"] * 1e-6)))

    def reset(self):
        self._rem = 0
        self._sign = 0
        self._dc = 0.0
        self._pulses = 0

    def process(self, x):
        if x.size == 0:
            return x
        thr = self._params["threshold"]
        out = np.zeros_like(x)
        rem, sign, plen, pulses = self._rem, self._sign, self._plen, self._pulses
        dc, alpha = self._dc, self._alpha
        for i in range(x.size):
            v = float(x[i])
            dc += alpha * (v - dc)
            d = v - dc
            if abs(d) <= thr:
                if rem > 0:
                    out[i] = 1.0
                    rem -= 1
                continue
            s = 1 if d > 0 else -1
            if sign != 0 and s != sign and rem == 0:
                rem = plen
                pulses += 1
            sign = s
            if rem > 0:
                out[i] = 1.0
                rem -= 1
        self._rem, self._sign, self._pulses, self._dc = rem, sign, pulses, dc
        return out

    def status(self):
        return f"{self._pulses} pulses"


# ---------------------------------------------------------------------------
#  Modulator
# ---------------------------------------------------------------------------

# mode indices (must match config.MODULATION_MODES order)
MODE_ZCP, MODE_PDM, MODE_PWM, MODE_AM, MODE_FM, MODE_ASK, MODE_DIRECT = range(7)


class Modulator(Block):
    """Converts an audio-rate envelope into the RF drive waveform.

    ``MODE_DIRECT`` passes the incoming signal straight through, which is
    what makes Elite2K fully back-compatible with upstream OpenV2K chains
    (enable the ``zcp`` block, select *Direct* here).
    """

    key, label, category, order_hint = "modulator", "Modulator", "modulation", 210

    @classmethod
    def param_specs(cls):
        return [
            P("mode", "Scheme", 0, 6, float(MODE_DIRECT), 1, "{:.0f}"),
            P("carrier_hz", "Carrier (AM/FM Hz)", 0.0, 20000.0, 0.0, 50.0, "{:.0f}"),
            P("fm_dev_hz", "FM deviation (Hz)", 0.0, 5000.0, 500.0, 25.0, "{:.0f}"),
            P("pulse_width_us", "Pulse width (us)", 5.0, 2000.0, 100.0, 5.0, "{:.0f}"),
            P("depth", "Depth", 0.0, 1.0, 1.0, 0.01, "{:.2f}"),
        ]

    def __init__(self):
        super().__init__()
        self._phase = 0.0          # carrier phase (radians)
        self._acc = 0.0            # sigma-delta accumulator
        self._sign = 0
        self._plen = 5
        self._rem = 0
        self._pulses = 0

    def on_rate(self, rate):
        self._refresh()

    def on_param(self, name, value):
        self._refresh()

    def _refresh(self):
        self._plen = max(1, int(round(self._rate * self._params["pulse_width_us"] * 1e-6)))

    def reset(self):
        self._phase = 0.0
        self._acc = 0.0
        self._sign = 0
        self._rem = 0
        self._pulses = 0

    def mode(self) -> int:
        return int(round(self._params["mode"]))

    def process(self, x):
        if x.size == 0:
            return x
        m = self.mode()
        if m == MODE_DIRECT:
            return x
        if m == MODE_ZCP:
            return self._zcp(x)
        if m == MODE_PDM:
            return self._pdm(x)
        if m == MODE_PWM:
            return self._pwm(x)
        if m == MODE_AM:
            return self._am(x)
        if m == MODE_FM:
            return self._fm(x)
        if m == MODE_ASK:
            return self._ask(x)
        return x

    # -- schemes ------------------------------------------------------------

    def _zcp(self, x):
        out = np.zeros_like(x)
        rem, sign, plen, pulses = self._rem, self._sign, self._plen, self._pulses
        for i in range(x.size):
            v = float(x[i])
            if v == 0.0:
                if rem > 0:
                    out[i] = 1.0
                    rem -= 1
                continue
            s = 1 if v > 0 else -1
            if sign != 0 and s != sign and rem == 0:
                rem, pulses = plen, pulses + 1
            sign = s
            if rem > 0:
                out[i] = 1.0
                rem -= 1
        self._rem, self._sign, self._pulses = rem, sign, pulses
        return out

    def _pdm(self, x):
        """First-order sigma-delta: pulse density tracks amplitude."""
        out = np.zeros_like(x)
        acc = self._acc
        depth = self._params["depth"]
        for i in range(x.size):
            target = max(0.0, min(1.0, (float(x[i]) + 1.0) * 0.5)) * depth
            if acc >= 0.5:
                out[i] = 1.0
                acc -= 1.0
            acc += target
        self._acc = acc
        return out

    def _pwm(self, x):
        """Duty cycle proportional to rectified amplitude at carrier rate."""
        n = x.size
        carr = self._params["carrier_hz"]
        if carr <= 0:
            carr = max(50.0, min(4000.0, self._rate / 12.0))
        step = carr / max(self._rate, 1.0)
        phase = self._phase
        depth = self._params["depth"]
        out = np.zeros_like(x)
        for i in range(n):
            duty = max(0.0, min(1.0, abs(float(x[i])) * depth))
            out[i] = 1.0 if phase < duty else 0.0
            phase += step
            if phase >= 1.0:
                phase -= 1.0
        self._phase = phase
        return out

    def _am(self, x):
        carr = self._params["carrier_hz"]
        if carr <= 0:
            carr = 10_000.0
        t = (np.arange(x.size) + self._phase) / max(self._rate, 1.0)
        carrier = np.cos(2.0 * math.pi * carr * t)
        self._phase = (self._phase + x.size) % max(self._rate, 1.0)
        depth = self._params["depth"]
        # DSB-with-carrier: (1-d) + d*x keeps a residual carrier when d<1.
        return (carrier * ((1.0 - depth) + depth * x)).astype(np.float32)

    def _fm(self, x):
        carr = self._params["carrier_hz"]
        if carr <= 0:
            carr = 2_500.0
        dev = self._params["fm_dev_hz"]
        phase = self._phase
        out = np.empty_like(x)
        dt = 1.0 / max(self._rate, 1.0)
        for i in range(x.size):
            phase += 2.0 * math.pi * (carr + dev * float(x[i])) * dt
            out[i] = math.cos(phase)
        self._phase = math.fmod(phase, 2.0 * math.pi)
        return out

    def _ask(self, x):
        thr = 0.05
        carr = self._params["carrier_hz"]
        if carr <= 0:
            carr = 20_000.0
        t = (np.arange(x.size) + self._phase) / max(self._rate, 1.0)
        carrier = np.cos(2.0 * math.pi * carr * t).astype(np.float32)
        self._phase = (self._phase + x.size) % max(self._rate, 1.0)
        gate = (np.abs(x) > thr).astype(np.float32)
        return carrier * gate

    def status(self):
        return f"mode {self.mode()}"


# ---------------------------------------------------------------------------
#  Registry
# ---------------------------------------------------------------------------

BLOCK_CLASSES: List[type] = [
    DcBlocker, HighPass, LowPass, BandPass, Notch, PreEmphasis, DeEmphasis,
    Agc, NoiseGate, EnvelopeFollower, SpectralSubtractor, Decimator,
    HalfWaveRectifier, Schmitt, HilbertEnvelope, ZeroCrossPulse, Modulator,
]

BLOCK_REGISTRY: Dict[str, type] = {c.key: c for c in BLOCK_CLASSES}


def default_order() -> List[str]:
    return [c.key for c in sorted(BLOCK_CLASSES, key=lambda c: c.order_hint)]


def make_block(key: str) -> Block:
    cls = BLOCK_REGISTRY[key]
    return cls()
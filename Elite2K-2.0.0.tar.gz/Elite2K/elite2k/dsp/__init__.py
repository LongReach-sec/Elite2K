#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Pure-NumPy DSP core: streaming block library and the runtime engine."""

from __future__ import annotations

from . import blocks, engine
from .blocks import (
    BLOCK_CLASSES,
    BLOCK_REGISTRY,
    Block,
    default_order,
    make_block,
)
from .engine import Engine, LinearResampler, Metrics

__all__ = [
    "blocks",
    "engine",
    "Block",
    "BLOCK_CLASSES",
    "BLOCK_REGISTRY",
    "default_order",
    "make_block",
    "Engine",
    "LinearResampler",
    "Metrics",
]
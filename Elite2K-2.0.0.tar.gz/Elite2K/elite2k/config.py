#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- configuration, constants, profiles and presets.

Elite2K is a from-scratch, dependency-light successor to the OpenV2K
zero-crossing pulse transmitter family (https://github.com/OpenV2K).

Unlike the reference implementation it does NOT require GNU Radio, HackRF
or PyQt at runtime: the DSP core is pure NumPy, the graphical front-end is
stdlib Tk, and hardware back-ends are discovered lazily and used only when
present.  Profiles let an operator capture and reproduce a full signal
chain + RF configuration as a small portable JSON document.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List

# ---------------------------------------------------------------------------
#  Identity
# ---------------------------------------------------------------------------

APP_NAME = "Elite2K"
VERSION_MAJOR = 2
VERSION_MINOR = 0
VERSION_PATCH = 0
VERSION = f"{VERSION_MAJOR}.{VERSION_MINOR}.{VERSION_PATCH}"
BUILD_STAMP = time.strftime("%Y/%m/%d")
WINDOW_TITLE = f"{APP_NAME} ({BUILD_STAMP} - v{VERSION})"
UPSTREAM = "https://github.com/OpenV2K"

# Profile documents written by this build carry a schema tag so future
# versions can migrate older files instead of rejecting them.
PROFILE_SCHEMA = "elite2k.profile/1"

# ---------------------------------------------------------------------------
#  Numeric constants
# ---------------------------------------------------------------------------

AUDIO_RATE = 48_000          # internal audio / envelope processing rate
DEFAULT_IQ_RATE = 2_000_000  # default complex output sample rate

# The 48 kHz pulse train is lifted to the IQ rate by a continuous fractional
# resampler (see elite2k.dsp.engine.LinearResampler) rather than a fixed
# interpolate/decimate pair, so any IQ rate in the range below is reachable.
# The default 2 MS/s happens to be the exact ratio 125/3, which keeps pulse
# timing crisp.

# Practical ceilings so a mis-set profile cannot lock the machine up.
MAX_IQ_RATE = 4_000_000
MIN_IQ_RATE = 100_000
MAX_CHUNK = 16_384

# Nominal energy of one transmitted pulse, used to turn the measured pulse
# width into a comparable peak-power figure (P_peak = E_pulse / tau_pulse).
# It is a stipulated reference inherited from the zero-crossing pulse
# literature, NOT a calibrated radiometric measurement of your hardware --
# treat energy_per_pulse_mj / peak_power_w as chain-to-chain comparisons.
PULSE_ENERGY_REFERENCE_MJ = 16.0

# ---------------------------------------------------------------------------
#  RF band presets (centre frequencies in Hz)
# ---------------------------------------------------------------------------

BAND_PRESETS: List[Dict[str, Any]] = [
    {"name": "70 cm ISM (433.92 MHz)", "hz": 433_920_000.0},
    {"name": "70 cm Amateur (435.00 MHz)", "hz": 435_000_000.0},
    {"name": "70 cm legacy (425.00 MHz)", "hz": 425_000_000.0},
    {"name": "23 cm Amateur (1296.00 MHz)", "hz": 1_296_000_000.0},
    {"name": "23 cm legacy (1300.00 MHz)", "hz": 1_300_000_000.0},
    {"name": "2.4 GHz ISM (2440.00 MHz)", "hz": 2_440_000_000.0},
    {"name": "Custom", "hz": None},
]

# ---------------------------------------------------------------------------
#  Modulation schemes exposed by the modulator block
# ---------------------------------------------------------------------------

MODULATION_MODES: List[Dict[str, str]] = [
    {"key": "zcp", "label": "Zero-Crossing Pulse (classic)"},
    {"key": "pdm", "label": "Pulse-Density (sigma-delta)"},
    {"key": "pwm", "label": "Pulse-Width Modulation"},
    {"key": "am", "label": "Amplitude Modulation (DSB)"},
    {"key": "fm", "label": "Frequency Modulation"},
    {"key": "ask", "label": "On/Off Keying (ASK)"},
    {"key": "direct", "label": "Direct (pass-through, upstream chain)"},
]

# ---------------------------------------------------------------------------
#  Output back-ends
# ---------------------------------------------------------------------------

BACKEND_MODES: List[Dict[str, str]] = [
    {"key": "sim", "label": "Simulated (headless, no RF)"},
    {"key": "iqfile", "label": "IQ Capture to file (.cfile/.wav)"},
    {"key": "hackrf", "label": "HackRF via hackrf_transfer (no GNU Radio)"},
    {"key": "gnuradio", "label": "GNU Radio / gr-osmosdr (SDR TX)"},
    {"key": "soapy", "label": "SoapySDR (SDR TX)"},
    {"key": "audio", "label": "Audio device (soundcard)"},
]

# ---------------------------------------------------------------------------
#  Theme
# ---------------------------------------------------------------------------

THEME = {
    "bg": "#0d1117",
    "panel": "#161b22",
    "panel_alt": "#1c2128",
    "border": "#30363d",
    "fg": "#e6edf3",
    "fg_dim": "#8b949e",
    "accent": "#2f81f7",
    "accent2": "#3fb950",
    "warn": "#d29922",
    "danger": "#f85149",
    "grid": "#21262d",
    "trace": "#58a6ff",
    "waterfall_lo": "#0d1117",
    "waterfall_hi": "#f0b429",
}

THEME_FONTS = {
    "ui": ("DejaVu Sans", 9),
    "ui_bold": ("DejaVu Sans", 9, "bold"),
    "mono": ("DejaVu Sans Mono", 9),
    "mono_small": ("DejaVu Sans Mono", 8),
    "title": ("DejaVu Sans", 13, "bold"),
    "section": ("DejaVu Sans", 8, "bold"),
}

# ---------------------------------------------------------------------------
#  Settings / profile model
# ---------------------------------------------------------------------------

@dataclass
class RFSettings:
    """Everything that defines the transmit side of the tool."""

    frequency_hz: float = 1_300_000_000.0
    iq_rate: int = DEFAULT_IQ_RATE
    tx_amplitude: float = 0.500          # baseband drive, 0.0 .. 1.0
    rf_gain_db: float = 0.0              # SDR front-end gain (dB)
    if_gain_db: float = 40.0
    bb_gain_db: float = 20.0
    freq_correction_ppm: int = 0
    antenna: str = ""

    def clamped(self) -> "RFSettings":
        self.iq_rate = int(max(MIN_IQ_RATE, min(MAX_IQ_RATE, self.iq_rate)))
        self.tx_amplitude = float(max(0.0, min(1.0, self.tx_amplitude)))
        return self


@dataclass
class SourceSettings:
    """Audio / envelope source selection."""

    # "tts" | "tone" | "noise" | "mic" | "silence"
    kind: str = "tone"
    tone_hz: float = 440.0
    tts_text: str = "elite two kay"
    tts_voice: str = "en"
    tts_speed: int = 130
    tts_pitch: int = 20
    loop_buffer: bool = True


@dataclass
class ChainSettings:
    """Modular chain configuration.

    ``order`` is the user-orderable list of block keys; ``enabled`` maps a
    block key to a boolean; ``params`` maps ``block.param`` to a value.
    Any key absent from ``order`` is appended with library defaults when a
    profile is loaded, which keeps old profiles forward-compatible.
    """

    order: List[str] = field(default_factory=list)
    enabled: Dict[str, bool] = field(default_factory=dict)
    params: Dict[str, Dict[str, float]] = field(default_factory=dict)


@dataclass
class AppProfile:
    """A complete, serialisable Elite2K configuration."""

    schema: str = PROFILE_SCHEMA
    name: str = "default"
    rf: RFSettings = field(default_factory=RFSettings)
    source: SourceSettings = field(default_factory=SourceSettings)
    chain: ChainSettings = field(default_factory=ChainSettings)
    backend: str = "sim"
    backend_target: str = ""      # file path, device args, etc.
    realtime: bool = False        # pace output to wall-clock

    # -- serialisation ------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["schema"] = PROFILE_SCHEMA
        d["app_version"] = VERSION
        return d

    def save(self, path: str) -> None:
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, sort_keys=True)
        os.replace(tmp, path)

    @classmethod
    def load(cls, path: str) -> "AppProfile":
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "AppProfile":
        prof = cls()
        prof.name = str(raw.get("name", "default"))
        prof.backend = str(raw.get("backend", "sim"))
        prof.backend_target = str(raw.get("backend_target", ""))
        prof.realtime = bool(raw.get("realtime", False))

        rf = raw.get("rf") or {}
        for k, v in rf.items():
            if hasattr(prof.rf, k):
                setattr(prof.rf, k, v)
        prof.rf.clamped()

        src = raw.get("source") or {}
        for k, v in src.items():
            if hasattr(prof.source, k):
                setattr(prof.source, k, v)

        ch = raw.get("chain") or {}
        prof.chain.order = [str(k) for k in ch.get("order", [])]
        prof.chain.enabled = {str(k): bool(v)
                              for k, v in (ch.get("enabled") or {}).items()}
        prof.chain.params = {
            str(bk): {str(pk): float(pv) for pk, pv in (pv or {}).items()}
            for bk, pv in (ch.get("params") or {}).items()
        }
        return prof


# ---------------------------------------------------------------------------
#  Built-in presets
# ---------------------------------------------------------------------------

# A preset is a partial profile dict merged over RFSettings/SourceSettings.
# They are intentionally small, readable and reproducible.

def _preset_chain(order_enabled: Dict[str, bool],
                  params: Dict[str, Dict[str, float]] | None = None
                  ) -> Dict[str, Any]:
    return {
        "order": list(order_enabled.keys()),
        "enabled": dict(order_enabled),
        "params": params or {},
    }


PRESETS: Dict[str, Dict[str, Any]] = {
    "Balanced (recommended)": {
        "backend": "sim",
        "rf": {"tx_amplitude": 0.5, "iq_rate": DEFAULT_IQ_RATE},
        "source": {"kind": "tone", "tone_hz": 440.0},
        "chain": _preset_chain(
            {
                "dcblock": True, "notch": False, "highpass": True,
                "lowpass": True, "bandpass": False, "preemph": False,
                "deemph": False, "agc": True, "noisegate": True,
                "envfollow": False, "spectralsub": False, "decimator": True,
                "hwrect": True, "schmitt": True, "hilbert": False,
                "zcp": True, "modulator": True,
            },
            {
                "lowpass": {"cutoff": 2300.0},
                "highpass": {"cutoff": 100.0},
                "zcp": {"pulse_width_us": 100.0},
                "modulator": {"mode": 6.0, "carrier_hz": 0.0, "pulse_width_us": 100.0},
            },
        ),
    },
    "Maximum penetration": {
        "backend": "sim",
        "rf": {"tx_amplitude": 0.707, "iq_rate": DEFAULT_IQ_RATE},
        "source": {"kind": "tone", "tone_hz": 180.0},
        "chain": _preset_chain(
            {
                "dcblock": True, "notch": True, "highpass": True,
                "lowpass": True, "bandpass": True, "preemph": False,
                "deemph": True, "agc": True, "noisegate": False,
                "envfollow": True, "spectralsub": True, "decimator": True,
                "hwrect": True, "schmitt": True, "hilbert": True,
                "zcp": True, "modulator": True,
            },
            {
                "lowpass": {"cutoff": 1800.0},
                "highpass": {"cutoff": 80.0},
                "bandpass": {"center": 600.0, "width": 500.0},
                "zcp": {"pulse_width_us": 60.0},
                "modulator": {"mode": 6.0, "carrier_hz": 0.0, "pulse_width_us": 60.0},
            },
        ),
    },
    "Diagnostic (no modulation)": {
        "backend": "sim",
        "rf": {"tx_amplitude": 0.25, "iq_rate": DEFAULT_IQ_RATE},
        "source": {"kind": "tone", "tone_hz": 1000.0},
        "chain": _preset_chain(
            {
                "dcblock": True, "notch": False, "highpass": False,
                "lowpass": False, "bandpass": False, "preemph": False,
                "deemph": False, "agc": False, "noisegate": False,
                "envfollow": False, "spectralsub": False, "decimator": False,
                "hwrect": False, "schmitt": False, "hilbert": False,
                "zcp": False, "modulator": True,
            },
            {"modulator": {"mode": 3.0, "carrier_hz": 10000.0}},
        ),
    },
    "PDM experiment": {
        "backend": "sim",
        "rf": {"tx_amplitude": 0.6, "iq_rate": DEFAULT_IQ_RATE},
        "source": {"kind": "tone", "tone_hz": 350.0},
        "chain": _preset_chain(
            {
                "dcblock": True, "notch": False, "highpass": True,
                "lowpass": True, "bandpass": False, "preemph": False,
                "deemph": False, "agc": True, "noisegate": False,
                "envfollow": False, "spectralsub": False, "decimator": False,
                "hwrect": False, "schmitt": False, "hilbert": False,
                "zcp": False, "modulator": True,
            },
            {"modulator": {"mode": 1.0, "pulse_width_us": 20.0}},
        ),
    },
}


def apply_preset(name: str) -> AppProfile:
    """Return a fresh :class:`AppProfile` with ``PRESETS[name]`` applied."""
    prof = AppProfile(name=name)
    data = PRESETS.get(name)
    if not data:
        return prof
    if "backend" in data:
        prof.backend = data["backend"]
    for k, v in (data.get("rf") or {}).items():
        if hasattr(prof.rf, k):
            setattr(prof.rf, k, v)
    for k, v in (data.get("source") or {}).items():
        if hasattr(prof.source, k):
            setattr(prof.source, k, v)
    ch = data.get("chain")
    if ch:
        prof.chain.order = list(ch.get("order", []))
        prof.chain.enabled = dict(ch.get("enabled", {}))
        prof.chain.params = {k: dict(v) for k, v in ch.get("params", {}).items()}
    prof.rf.clamped()
    return prof


def default_profile_path() -> str:
    base = os.path.join(os.path.expanduser("~"), ".config", "elite2k")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "last_profile.json")
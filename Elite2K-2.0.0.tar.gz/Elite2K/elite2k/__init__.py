#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- a from-scratch, dependency-light successor to the OpenV2K
zero-crossing pulse RF transmitter family.

Public surface::

    import elite2k
    prof = elite2k.apply_preset("Balanced (recommended)")
    eng  = elite2k.Engine(prof)
    eng.start()

The graphical front-end lives in :mod:`elite2k.gui` and is launched by the
top-level ``Elite2K.py`` script.  Nothing here imports Tk, so the DSP core
and the back-ends are usable head-less (CI, batch conversion, embedded).
"""

from __future__ import annotations

from . import config
from .dsp.engine import Engine, Metrics, LinearResampler
from .dsp.blocks import (
    BLOCK_CLASSES,
    BLOCK_REGISTRY,
    Block,
    default_order,
    make_block,
)
from .config import (
    APP_NAME,
    VERSION,
    WINDOW_TITLE,
    UPSTREAM,
    AppProfile,
    RFSettings,
    SourceSettings,
    ChainSettings,
    PRESETS,
    MODULATION_MODES,
    BACKEND_MODES,
    BAND_PRESETS,
    apply_preset,
    default_profile_path,
)

__all__ = [
    "APP_NAME",
    "VERSION",
    "WINDOW_TITLE",
    "UPSTREAM",
    "config",
    "Engine",
    "Metrics",
    "LinearResampler",
    "Block",
    "BLOCK_CLASSES",
    "BLOCK_REGISTRY",
    "default_order",
    "make_block",
    "AppProfile",
    "RFSettings",
    "SourceSettings",
    "ChainSettings",
    "PRESETS",
    "MODULATION_MODES",
    "BACKEND_MODES",
    "BAND_PRESETS",
    "apply_preset",
    "default_profile_path",
]

__version__ = VERSION
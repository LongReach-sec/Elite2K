#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- head-less GUI regression harness (``Elite2K.py --guitest``).

The console is the part of Elite2K that a DSP self-test cannot cover: widget
construction, the worker-thread/UI hand-off, the chain editor and the preset
machinery all live on the Tk main loop.  This module drives a real
:class:`~elite2k.gui.app.Elite2KApp` instance without a human and without a
physical display (run it under ``xvfb-run`` on a headless host).

What it exercises
-----------------
1. **build**      -- the full window constructs and owns a plausible widget
                     tree (no ``TclError``, no missing style).
2. **transport**  -- START / PAUSE / PAUSE / STOP drive the engine state
                     machine and keep the button states consistent.
3. **warm-up**    -- with the simulated back-end running, the pump loop plus
                     the engine worker thread actually produce IQ within a
                     bounded budget (this is the check the old ad-hoc smoke
                     script lacked, which is why it reported ``iq=0``).
4. **panels**     -- spectrum / scope / waterfall feed and the metric
                     dashboard reflect that traffic.
5. **presets**    -- every built-in preset loads through the same code path
                     the toolbar uses, and the resulting chain matches the
                     preset's ``enabled`` map.
6. **chain**      -- block enable toggle, reorder and per-block parameter
                     edits reach the engine.
7. **sources**    -- every source kind and back-end key can be selected
                     through the UI variables without raising.
8. **teardown**   -- the window closes cleanly, stopping the engine thread.

Exit status is ``0`` when every check passes, ``1`` otherwise.  Nothing here
writes outside the process, and no SDR hardware is required.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from typing import Any, Callable, Dict, List, Optional, Tuple

from . import config

__all__ = ["run", "Guitest"]


# ---------------------------------------------------------------------------
#  Tiny check harness
# ---------------------------------------------------------------------------

class _Report:
    """Collects pass/fail results and prints them in grouped form."""

    def __init__(self, verbose: bool = True) -> None:
        self.verbose = verbose
        self.groups: List[Tuple[str, List[Tuple[str, bool, str]]]] = []

    def group(self, name: str) -> None:
        self.groups.append((name, []))
        if self.verbose:
            print("\n[%s]" % name)

    def check(self, name: str, ok: bool, detail: str = "") -> bool:
        if not self.groups:
            self.group("general")
        self.groups[-1][1].append((name, bool(ok), detail))
        if self.verbose:
            tag = "PASS" if ok else "FAIL"
            pad = "." * max(2, 46 - len(name))
            print("  %s %s %s%s" % (tag, name, pad, (" " + detail) if detail else ""))
        return bool(ok)

    def attempt(self, name: str, fn: Callable[[], Any],
                detail: str = "") -> Tuple[bool, Any]:
        """Run ``fn``; a raised exception becomes a failed check."""
        try:
            out = fn()
        except Exception as exc:                      # noqa: BLE001 - reporting
            self.check(name, False, "raised %r" % (exc,))
            if self.verbose:
                traceback.print_exc()
            return False, None
        self.check(name, True, detail)
        return True, out

    # -- summary ------------------------------------------------------------
    @property
    def passed(self) -> int:
        return sum(1 for _n, rows in self.groups for _c, ok, _d in rows if ok)

    @property
    def failed(self) -> int:
        return sum(1 for _n, rows in self.groups for _c, ok, _d in rows if not ok)

    def render_summary(self) -> str:
        lines = ["", "=" * 62, "GUI TEST SUMMARY".center(62), "=" * 62]
        for name, rows in self.groups:
            ok = sum(1 for _c, o, _d in rows if o)
            lines.append("  %-14s %2d/%2d" % (name, ok, len(rows)))
        lines.append("-" * 62)
        lines.append("  total: %d passed, %d failed" % (self.passed, self.failed))
        if self.failed:
            lines.append("")
            lines.append("  failures:")
            for name, rows in self.groups:
                for cname, ok, detail in rows:
                    if not ok:
                        lines.append("    - [%s] %s %s" % (name, cname, detail))
        lines.append("=" * 62)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
#  GUI harness
# ---------------------------------------------------------------------------

class Guitest:
    """Drives an ``Elite2KApp`` head-lessly and reports structured results."""

    def __init__(self, timeout: float = 20.0, verbose: bool = True,
                 keep_open: bool = False) -> None:
        self.timeout = float(timeout)
        self.keep_open = keep_open
        self.rep = _Report(verbose)
        self.app = None
        self.tmpdir: Optional[str] = None

    # -- utilities ----------------------------------------------------------
    def _count_widgets(self, root) -> int:
        total, seen, stack = 0, set(), [root]
        while stack:
            w = stack.pop()
            if id(w) in seen:
                continue
            seen.add(id(w))
            total += 1
            try:
                stack.extend(w.winfo_children())
            except Exception:
                pass
        return total

    def _pump(self, seconds: float = 0.0, iterations: int = 1) -> None:
        """Service the Tk event loop (fires ``after`` ticks) ``iterations`` times."""
        deadline = time.time() + seconds
        n = 0
        while True:
            self.app.update_idletasks()
            self.app.update()
            n += 1
            if seconds > 0.0:
                if time.time() >= deadline:
                    return
                time.sleep(0.02)
            elif n >= iterations:
                return

    def _await(self, predicate: Callable[[], bool], budget: float,
               poll: float = 0.05) -> bool:
        """Pump the loop until ``predicate`` holds or ``budget`` elapses."""
        deadline = time.time() + budget
        while time.time() < deadline:
            if predicate():
                return True
            self._pump(0.0, 1)
            time.sleep(poll)
        self._pump(0.0, 1)
        return predicate()

    def _chain_map(self) -> Dict[str, bool]:
        return {b.key: bool(b.enabled) for b in self.app.engine.block_chain()}

    # -- checks -------------------------------------------------------------
    def check_build(self) -> None:
        self.rep.group("build")
        from .gui.app import Elite2KApp

        ok, app = self.rep.attempt("window constructs", Elite2KApp)
        if not ok or app is None:
            return
        self.app = app
        self._pump(0.2)
        widgets = self._count_widgets(app)
        self.rep.check("widget tree populated", widgets > 200, "%d widgets" % widgets)
        for attr, label in (("spectrum", "spectrum view"),
                            ("waterfall", "waterfall view"),
                            ("scope", "scope view"),
                            ("chain", "chain editor"),
                            ("metric_vars", "metric dashboard")):
            self.rep.check("%s present" % label, hasattr(app, attr))
        self.rep.check("engine attached", app.engine is not None)
        self.rep.check("log pane writable", hasattr(app, "log_text"))

    def check_transport(self) -> None:
        self.rep.group("transport")
        app = self.app
        if app is None:
            self.rep.check("transport available", False, "no app")
            return

        self.rep.attempt("START", app._start)
        self._pump(0.2)
        self.rep.check("engine running after START", bool(app.engine.running))
        self.rep.check("START button disabled",
                       str(app.start_btn.cget("state")) == "disabled")
        self.rep.check("STOP button enabled",
                       str(app.stop_btn.cget("state")) == "normal")

        self.rep.attempt("PAUSE", app._pause)
        self._pump(0.1)
        self.rep.check("engine paused", bool(app.engine.snapshot()["paused"]))

        self.rep.attempt("RESUME", app._pause)
        self._pump(0.1)
        self.rep.check("engine resumed", not bool(app.engine.snapshot()["paused"]))

        self.rep.attempt("STOP", app._stop)
        self._pump(0.1)
        self.rep.check("engine stopped", not bool(app.engine.running))
        self.rep.check("START button re-enabled",
                       str(app.start_btn.cget("state")) == "normal")

    def check_warmup(self) -> None:
        """The check the original smoke script got wrong: give the worker time."""
        self.rep.group("warm-up")
        app = self.app
        if app is None:
            self.rep.check("engine startable", False, "no app")
            return

        self.rep.attempt("START again", app._start)
        t0 = time.time()
        got = self._await(
            lambda: app.engine.snapshot()["metrics"].iq_samples > 0,
            self.timeout)
        elapsed = time.time() - t0
        snap = app.engine.snapshot()
        m = snap["metrics"]
        self.rep.check("IQ produced within budget", got,
                       "%d samples in %.2fs" % (m.iq_samples, elapsed))
        self.rep.check("working rate > 0", m.working_rate > 0.0,
                       "%.1f Hz" % m.working_rate)
        self.rep.check("no engine error", not m.error, m.error or "-")

        base = m.iq_samples
        self._pump(0.6)
        grew = app.engine.snapshot()["metrics"].iq_samples
        self.rep.check("IQ advances while running", grew > base,
                       "%d -> %d" % (base, grew))

        self.rep.attempt("PAUSE", app._pause)
        self._pump(0.3)
        p1 = app.engine.snapshot()["metrics"].iq_samples
        self._pump(0.4)
        p2 = app.engine.snapshot()["metrics"].iq_samples
        self.rep.check("IQ frozen while paused", p2 == p1, "%d == %d" % (p2, p1))
        self.rep.attempt("RESUME", app._pause)
        self._pump(0.3)

    def check_panels(self) -> None:
        self.rep.group("panels")
        app = self.app
        if app is None:
            self.rep.check("panels available", False, "no app")
            return
        self._pump(0.6)
        snap = app.engine.snapshot()

        import numpy as np
        sp = np.asarray(snap["spectrum_db"], dtype=np.float32)
        sc = np.asarray(snap["scope"], dtype=np.float32)
        wf = np.asarray(snap["waterfall"], dtype=np.float32)
        self.rep.check("spectrum has bins", sp.size > 0, "%d bins" % sp.size)
        self.rep.check("spectrum is finite",
                       bool(np.all(np.isfinite(sp))) if sp.size else False)
        self.rep.check("spectrum not silent",
                       bool(np.any(sp > -200.0)) if sp.size else False)
        self.rep.check("scope trace populated", sc.size > 0, "%d samples" % sc.size)
        self.rep.check("waterfall rows rolling", wf.size > 0,
                       "shape=%s" % (tuple(wf.shape),))

        self.rep.attempt("spectrum widget repaint", lambda: app.spectrum.update_data(
            snap["spectrum_db"], snap["spectrum_rate"]))
        self.rep.attempt("scope widget repaint",
                         lambda: app.scope.update_data(snap["scope"]))
        self.rep.attempt("waterfall widget render",
                         lambda: app.waterfall.set_rows(snap["waterfall"]) or
                         app.waterfall.render())

        v = app.metric_vars
        self.rep.check("dashboard iq_samples non-zero", v["iq_samples"].get() != "0",
                       v["iq_samples"].get())
        self.rep.check("dashboard state shown", bool(v["state"].get()),
                       v["state"].get())

    def check_presets(self) -> None:
        self.rep.group("presets")
        app = self.app
        if app is None:
            self.rep.check("presets loadable", False, "no app")
            return
        for name in config.PRESETS:
            app.preset_var.set(name)
            ok, _ = self.rep.attempt("load %r" % name, app._load_preset)
            if not ok:
                continue
            self._pump(0.4)
            want = (config.PRESETS[name].get("chain") or {}).get("enabled") or {}
            got = self._chain_map()
            mismatch = [k for k, val in want.items()
                        if k in got and got[k] != bool(val)]
            self.rep.check("  chain matches preset", not mismatch,
                           "mismatch=%s" % mismatch if mismatch else
                           "%d blocks" % len(got))
            self.rep.check("  UI reflects preset",
                           app.profile.name == name or name in app.profile.name,
                           app.profile.name)
            rows = len(getattr(app.chain, "_rows", {}))
            self.rep.check("  chain editor rebuilt", rows == len(got),
                           "%d rows / %d blocks" % (rows, len(got)))
        # leave the default profile in place
        app.preset_var.set("Balanced (recommended)")
        self.rep.attempt("restore default preset", app._load_preset)
        self._pump(0.2)

    def check_chain(self) -> None:
        self.rep.group("chain")
        app = self.app
        if app is None:
            self.rep.check("chain editable", False, "no app")
            return
        app.preset_var.set("Balanced (recommended)")
        app._load_preset()
        self._pump(0.2)
        chain = app.chain
        keys = [b.key for b in app.engine.block_chain()]
        self.rep.check("chain non-empty", len(keys) > 0, "%d blocks" % len(keys))
        if not keys:
            return
        target = keys[0]

        # -- enable / disable through the editor callback -------------------
        self.rep.attempt("toggle %s off" % target,
                         lambda: chain._toggle(target, False))
        self.rep.check("engine saw disable", self._chain_map().get(target) is False)
        self.rep.attempt("toggle %s on" % target,
                         lambda: chain._toggle(target, True))
        self.rep.check("engine saw enable", self._chain_map().get(target) is True)

        # -- reorder -------------------------------------------------------
        before = [b.key for b in app.engine.block_chain()]
        if len(before) > 1:
            self.rep.attempt("move last block up",
                             lambda: chain._move(before[-1], -1))
            after = [b.key for b in app.engine.block_chain()]
            self.rep.check("order changed", after != before,
                           "%s -> %s" % (before[-1], after.index(before[-1])))
            self.rep.attempt("move it back down",
                             lambda: chain._move(before[-1], +1))
            self.rep.check("order restored",
                           [b.key for b in app.engine.block_chain()] == before)

        # -- parameter write -----------------------------------------------
        blk = next(b for b in app.engine.block_chain() if b.key == target)
        specs = blk.param_specs()
        if specs:
            spec = specs[0]
            lo, hi = float(spec["lo"]), float(spec["hi"])
            newval = lo + (hi - lo) * 0.25
            self.rep.attempt("write %s.%s" % (target, spec["name"]),
                             lambda: chain._set_param(target, spec["name"], newval))
            blk2 = next(b for b in app.engine.block_chain() if b.key == target)
            got = float(blk2._params.get(spec["name"], float("nan")))
            self.rep.check("parameter persisted",
                           abs(got - newval) <= max(1e-9, abs(newval) * 0.5),
                           "%s=%s (asked %s)" % (spec["name"], got, newval))
        # reload the preset so the engine is left on stock values
        app._load_preset()
        self._pump(0.2)

    def check_sources(self) -> None:
        self.rep.group("sources / backends")
        app = self.app
        if app is None:
            self.rep.check("sources selectable", False, "no app")
            return
        # source kinds are the radio values built in Elite2KApp._build_left
        for kind in ("tone", "noise", "mic", "tts", "silence"):
            app.src_var.set(kind)
            self.rep.attempt("source %r" % kind, app._apply_source)
            self.rep.check("  profile.source.kind == %r" % kind,
                           app.profile.source.kind == kind,
                           app.profile.source.kind)
        app.src_var.set("tone")
        app._apply_source()

        for mode in config.BACKEND_MODES:
            key, label = mode["key"], mode["label"]
            app.back_var.set(label)
            self.rep.attempt("backend %r applied" % key, app._apply_backend)
            self.rep.check("  profile.backend == %r" % key,
                           app.profile.backend == key, app.profile.backend)
        app.profile.backend = "sim"
        app._apply_backend()
        self._pump(0.1)

    def check_profile_roundtrip(self) -> None:
        self.rep.group("profiles")
        app = self.app
        if app is None:
            self.rep.check("profile round-trip", False, "no app")
            return
        import json
        import tempfile

        self.tmpdir = self.tmpdir or tempfile.mkdtemp(prefix="elite2k_guitest_")
        path = os.path.join(self.tmpdir, "roundtrip.json")
        app.profile.name = "guitest-roundtrip"
        self.rep.attempt("save profile JSON", lambda: app.profile.save(path))
        self.rep.check("file written", os.path.isfile(path))
        try:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            self.rep.check("schema version present",
                           str(raw.get("schema", raw.get("schema_version", ""))) != "",
                           str(raw.get("schema", raw.get("schema_version", ""))))
        except Exception as exc:                       # noqa: BLE001
            self.rep.check("schema version present", False, "unreadable: %r" % exc)

        ok, prof = self.rep.attempt("reload profile JSON",
                                    lambda: config.AppProfile.load(path))
        if ok and prof is not None:
            self.rep.check("name round-trips", prof.name == "guitest-roundtrip",
                           prof.name)
            app.profile = prof
            self.rep.attempt("apply reloaded profile",
                             lambda: app.engine.apply_profile(prof))
            self.rep.attempt("sync UI from profile", app._sync_from_profile)
            self.rep.attempt("rebuild chain editor", app.chain.refresh)

    def check_tts_panel(self) -> None:
        self.rep.group("tts panel")
        app = self.app
        if app is None:
            self.rep.check("tts callable", False, "no app")
            return
        from .backend import tts as tts_mod
        voices = sorted(tts_mod.VOICE_MAP.keys())
        self.rep.check("voice list exposed", bool(voices), "%d voices" % len(voices))
        ok, res = self.rep.attempt(
            "synthesize sample phrase",
            lambda: tts_mod.synthesize("elite two kay", voice=(voices[0] if voices else "en"),
                                       speed=175, pitch=50))
        samples = None
        if ok and isinstance(res, tuple) and len(res) == 2:
            samples, label = res
            self.rep.check("tts reports engine", bool(label), str(label))
        if samples is not None:
            self.rep.check("tts produced samples", getattr(samples, "size", 0) > 0,
                           "%d samples" % getattr(samples, "size", 0))
            self.rep.attempt("engine accepts TTS buffer",
                             lambda: app.engine.set_tts_buffer(samples, loop=False,
                                                               label="guitest"))
            self.rep.attempt("pump with TTS loaded", lambda: self._pump(0.4))
            self.rep.check("no engine error after TTS",
                           not app.engine.snapshot()["metrics"].error,
                           app.engine.snapshot()["metrics"].error or "-")

    def check_teardown(self) -> None:
        self.rep.group("teardown")
        app = self.app
        if app is None:
            return
        self.rep.attempt("window closes", app._on_close)
        self.rep.check("engine stopped after close",
                       not bool(getattr(app.engine, "running", False)))
        self.app = None

    # -- driver -------------------------------------------------------------
    def run(self) -> int:
        print("Elite2K GUI test -- Tk %s, display %r"
              % (self._tk_version(), os.environ.get("DISPLAY", ":none")))
        started = time.time()
        try:
            self.check_build()
            self.check_transport()
            self.check_warmup()
            self.check_panels()
            self.check_presets()
            self.check_chain()
            self.check_sources()
            self.check_profile_roundtrip()
            self.check_tts_panel()
        except Exception:                              # noqa: BLE001 - reporting
            traceback.print_exc()
            self.rep.check("harness survived", False, "unexpected exception")
        finally:
            if self.app is not None and not self.keep_open:
                self.check_teardown()
            elif self.keep_open and self.app is not None:
                print("\n--keep: leaving the window open, close it to exit")
                try:
                    self.app.mainloop()
                except Exception:
                    pass
        print(self.rep.render_summary())
        print("elapsed %.2fs" % (time.time() - started))
        return 0 if self.rep.failed == 0 else 1

    @staticmethod
    def _tk_version() -> str:
        try:
            import tkinter
            return str(tkinter.TkVersion)
        except Exception:
            return "?"


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

def run(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="Elite2K --guitest",
        description="Head-less Tk regression test for the Elite2K console.")
    ap.add_argument("--timeout", type=float, default=20.0,
                    help="seconds of engine warm-up budget (default 20)")
    ap.add_argument("--quiet", action="store_true", help="summary only")
    ap.add_argument("--keep", action="store_true", help="leave the window open")
    args = ap.parse_args(argv)

    try:
        import tkinter  # noqa: F401
    except Exception as exc:                           # noqa: BLE001
        print("GUI test unavailable: Tkinter not importable (%s)" % exc)
        print("On a head-less host run:  xvfb-run -a python3 Elite2K.py --guitest")
        return 1

    if not os.environ.get("DISPLAY") and sys.platform.startswith("linux"):
        print("note: no DISPLAY set -- this host needs Xvfb "
              "(xvfb-run -a python3 Elite2K.py --guitest)")

    return Guitest(timeout=args.timeout, verbose=not args.quiet,
                   keep_open=args.keep).run()


if __name__ == "__main__":                             # pragma: no cover
    raise SystemExit(run())

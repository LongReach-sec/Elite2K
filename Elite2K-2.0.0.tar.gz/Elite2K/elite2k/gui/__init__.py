#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Tk front-end for Elite2K."""

from __future__ import annotations

from .app import Elite2KApp, main

__all__ = ["Elite2KApp", "main"]
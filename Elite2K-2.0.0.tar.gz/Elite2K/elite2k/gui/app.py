#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- Tk graphical front-end.

A single-window, dark-themed console that drives the pure-NumPy DSP engine:

* live RF spectrum (Hann-windowed, fft-shifted, dB),
* rolling waterfall rendered through a Tk ``PhotoImage`` (no Pillow),
* time-domain scope of the baseband drive,
* a modular, reorderable chain editor with per-block parameter sliders,
* RF / source / back-end configuration and portable JSON profiles,
* a metrics dashboard and event log.

Everything runs on the Tk main thread; the DSP engine runs on its own
worker thread and communicates only through :meth:`Engine.snapshot` and a
thread-safe log queue.  No third-party dependency is required.
"""

from __future__ import annotations

import base64
import math
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Any, Dict, List, Optional

from .. import config
from ..backend import sinks as sink_mod
from ..backend import tts as tts_mod
from ..dsp.engine import Engine
from ..dsp import blocks as block_mod

# ---------------------------------------------------------------------------
#  Colour helpers
# ---------------------------------------------------------------------------

# Waterfall colour ramp (low -> high energy), lifted from the theme palette.
_WF_STOPS = [
    (13, 17, 23),     # #0d1117  background
    (16, 42, 110),    # deep blue
    (24, 120, 190),   # blue
    (63, 185, 80),    # green
    (240, 180, 41),   # amber
    (255, 245, 210),  # hot core
]


def _waterfall_rgb(db_rows, lo: float = -110.0, hi: float = -10.0):
    """Map a 2-D array of dB values to an ``(h, w, 3)`` uint8 RGB block."""
    import numpy as np

    arr = np.asarray(db_rows, dtype=np.float32)
    if arr.ndim != 2 or arr.size == 0:
        return None
    t = (arr - lo) / max(1e-6, (hi - lo))
    t = np.clip(t, 0.0, 1.0)
    stops = np.asarray(_WF_STOPS, dtype=np.float32)
    n = len(_WF_STOPS)
    x = t * (n - 1)
    idx = np.clip(np.floor(x).astype(np.int32), 0, n - 2)
    frac = (x - idx)[..., None]
    rgb = stops[idx] * (1.0 - frac) + stops[idx + 1] * frac
    return rgb.astype(np.uint8)


def _ppm_base64(rgb) -> str:
    """Encode an ``(h, w, 3)`` uint8 array as a base64 PPM (P6) blob."""
    h, w, _ = rgb.shape
    header = b"P6\n%d %d\n255\n" % (w, h)
    return base64.b64encode(header + rgb.tobytes()).decode("ascii")


# ---------------------------------------------------------------------------
#  Small reusable widgets
# ---------------------------------------------------------------------------

class _ScrollFrame(ttk.Frame):
    """A vertically scrollable frame (mouse-wheel + scrollbar)."""

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.canvas = tk.Canvas(self, bg=config.THEME["panel"], highlightthickness=0,
                                bd=0)
        self.vs = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vs.set)
        self.vs.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind("<Configure>", self._on_canvas)
        self.canvas.bind("<Enter>", lambda _e: self._bind_wheel())
        self.canvas.bind("<Leave>", lambda _e: self._unbind_wheel())

    def _on_inner(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas(self, e):
        self.canvas.itemconfigure(self._win, width=e.width)

    def _bind_wheel(self):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _unbind_wheel(self):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _wheel(self, e):
        if getattr(e, "num", None) == 4:
            delta = -1
        elif getattr(e, "num", None) == 5:
            delta = 1
        else:
            delta = -1 if e.delta > 0 else 1
        self.canvas.yview_scroll(delta, "units")


class _NumericField(ttk.Frame):
    """Label + entry + slider + formatted readout for one numeric value."""

    def __init__(self, master, label: str, lo: float, hi: float, value: float,
                 step: float, fmt: str, on_change, integer: bool = False,
                 unit: str = ""):
        super().__init__(master)
        self.lo, self.hi, self.step = float(lo), float(hi), float(step)
        self.fmt = fmt
        self.on_change = on_change
        self.integer = integer
        self.unit = unit
        self._var = tk.DoubleVar(value=float(value))
        self._after: Optional[str] = None

        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Label(top, text=label, style="Field.TLabel").pack(side="left")
        self.readout = ttk.Label(top, text=self._fmt(value), style="Value.TLabel")
        self.readout.pack(side="right")

        self.scale = ttk.Scale(self, from_=self.lo, to=self.hi, variable=self._var,
                               command=self._on_scale)
        self.scale.pack(fill="x", pady=(1, 0))

    def _fmt(self, v: float) -> str:
        try:
            s = self.fmt.format(float(v))
        except Exception:
            s = "%.3g" % float(v)
        return s + ((" " + self.unit) if self.unit else "")

    def _on_scale(self, _val=None):
        v = self._var.get() if not self.integer else round(self._var.get())
        self.readout.configure(text=self._fmt(v))
        # debounce bursts of slider motion
        if self._after is not None:
            self.after_cancel(self._after)
        self._after = self.after(40, lambda: self._commit(v))

    def _commit(self, v):
        self._after = None
        try:
            self.on_change(float(v))
        except Exception:
            pass

    def set_value(self, v: float):
        self._var.set(float(v))
        self.readout.configure(text=self._fmt(v))


# ---------------------------------------------------------------------------
#  Visualisation widgets
# ---------------------------------------------------------------------------

class SpectrumView(ttk.Frame):
    """Live IQ power spectrum in dB."""

    def __init__(self, master):
        super().__init__(master)
        ttk.Label(self, text="RF SPECTRUM  (dB, fft-shifted)", style="Section.TLabel").pack(
            anchor="w", padx=4, pady=(2, 0))
        self.canvas = tk.Canvas(self, bg=config.THEME["bg"], highlightthickness=0,
                                height=190)
        self.canvas.pack(fill="both", expand=True, padx=2, pady=2)
        self._last = None
        self.canvas.bind("<Configure>", lambda _e: self._redraw())

    def update_data(self, db, rate_hz: float):
        try:
            import numpy as np
            self._last = (np.asarray(db, dtype=np.float32), float(rate_hz))
        except Exception:
            self._last = None
        self._redraw()

    def _redraw(self):
        c = self.canvas
        w = max(40, c.winfo_width())
        h = max(40, c.winfo_height())
        c.delete("all")
        # grid
        for i in range(1, 4):
            y = h * i / 4.0
            c.create_line(0, y, w, y, fill=config.THEME["grid"])
        for i in range(1, 8):
            x = w * i / 8.0
            c.create_line(x, 0, x, h, fill=config.THEME["grid"])
        c.create_text(4, 8, anchor="nw", fill=config.THEME["fg_dim"],
                      text="-10 dB", font=config.THEME_FONTS["mono_small"])
        c.create_text(4, h - 10, anchor="nw", fill=config.THEME["fg_dim"],
                      text="-120 dB", font=config.THEME_FONTS["mono_small"])
        if self._last is None:
            c.create_text(w // 2, h // 2, fill=config.THEME["fg_dim"],
                          text="no signal", font=config.THEME_FONTS["ui"])
            return
        db, rate = self._last
        if db.size < 2:
            return
        import numpy as np
        n = min(db.size, w)
        idx = np.linspace(0, db.size - 1, n).astype(np.int32)
        vals = db[idx]
        lo, hi = -120.0, -10.0
        pts: List[float] = []
        for i, v in enumerate(vals):
            x = (i / (n - 1)) * w
            y = h - (float(v) - lo) / (hi - lo) * h
            y = max(0.0, min(float(h), y))
            pts.extend((x, y))
        if len(pts) >= 4:
            c.create_line(*pts, fill=config.THEME["trace"], width=1, smooth=False)
        if rate > 0:
            c.create_text(w - 6, 8, anchor="ne", fill=config.THEME["fg_dim"],
                          text="+/- %.2f MHz" % (rate / 2e6),
                          font=config.THEME_FONTS["mono_small"])


class WaterfallView(ttk.Frame):
    """Rolling waterfall using a single Tk PhotoImage (PPM, no Pillow)."""

    COLS = 192

    def __init__(self, master):
        super().__init__(master)
        ttk.Label(self, text="WATERFALL  (newest at top)", style="Section.TLabel").pack(
            anchor="w", padx=4, pady=(2, 0))
        self.canvas = tk.Canvas(self, bg=config.THEME["bg"], highlightthickness=0,
                                height=200)
        self.canvas.pack(fill="both", expand=True, padx=2, pady=2)
        self._img: Optional[tk.PhotoImage] = None
        self._item: Optional[int] = None
        self._photo_ref: Optional[str] = None
        self._rows: List[Any] = []
        self._dirty = False

    def set_rows(self, rows: List[Any]):
        self._rows = rows
        self._dirty = True

    def render(self):
        if not self._dirty:
            return
        self._dirty = False
        rows = self._rows
        if not rows:
            return
        import numpy as np
        w = max(32, self.canvas.winfo_width())
        h = max(32, self.canvas.winfo_height())
        n = self.COLS
        # newest first (deque appends newest at the end)
        data = []
        for row in reversed(rows):
            a = np.asarray(row, dtype=np.float32)
            if a.size == 0:
                continue
            if a.size != n:
                idx = np.clip(np.linspace(0, a.size - 1, n).astype(np.int32), 0, a.size - 1)
                a = a[idx]
            data.append(a)
        if not data:
            return
        arr = np.stack(data, axis=0)                 # (rows, n)
        # vertical resample to canvas height
        target_h = min(240, max(20, h - 4))
        if arr.shape[0] != target_h:
            ridx = np.clip(np.linspace(0, arr.shape[0] - 1, target_h).astype(np.int32),
                           0, arr.shape[0] - 1)
            arr = arr[ridx]
        rgb = _waterfall_rgb(arr)
        if rgb is None:
            return
        try:
            data_b64 = _ppm_base64(rgb)
            img = tk.PhotoImage(data=data_b64, format="ppm")
        except Exception:
            return
        self._img = img
        if self._item is None:
            self._item = self.canvas.create_image(0, 0, anchor="nw", image=self._img)
        else:
            self.canvas.itemconfigure(self._item, image=self._img)
        self.canvas.coords(self._item, 0, 0)


class ScopeView(ttk.Frame):
    """Time-domain scope of the baseband drive."""

    def __init__(self, master):
        super().__init__(master)
        ttk.Label(self, text="SCOPE  (baseband drive)", style="Section.TLabel").pack(
            anchor="w", padx=4, pady=(2, 0))
        self.canvas = tk.Canvas(self, bg=config.THEME["bg"], highlightthickness=0,
                                height=120)
        self.canvas.pack(fill="both", expand=True, padx=2, pady=2)
        self._data = None
        self.canvas.bind("<Configure>", lambda _e: self._redraw())

    def update_data(self, scope):
        try:
            import numpy as np
            self._data = np.asarray(scope, dtype=np.float32)
        except Exception:
            self._data = None
        self._redraw()

    def _redraw(self):
        c = self.canvas
        w = max(40, c.winfo_width())
        h = max(30, c.winfo_height())
        c.delete("all")
        mid = h / 2.0
        c.create_line(0, mid, w, mid, fill=config.THEME["grid"])
        for i in range(1, 8):
            x = w * i / 8.0
            c.create_line(x, 0, x, h, fill=config.THEME["grid"])
        if self._data is None or self._data.size < 2:
            return
        import numpy as np
        n = self._data.size
        idx = np.linspace(0, n - 1, min(n, w)).astype(np.int32)
        vals = self._data[idx]
        scale = max(1e-3, float(np.max(np.abs(vals))))
        pts: List[float] = []
        for i, v in enumerate(vals):
            x = (i / (len(vals) - 1)) * w
            y = mid - (float(v) / scale) * (h / 2.0 - 4)
            pts.extend((x, max(2.0, min(h - 2.0, y))))
        if len(pts) >= 4:
            c.create_line(*pts, fill=config.THEME["accent2"], width=1)


# ---------------------------------------------------------------------------
#  Chain editor
# ---------------------------------------------------------------------------

class ChainEditor(ttk.Frame):
    """Reorderable, per-block parameter editor backed by the running engine."""

    def __init__(self, master, engine: Engine, on_log):
        super().__init__(master)
        self.engine = engine
        self.on_log = on_log
        ttk.Label(self, text="CHAIN EDITOR", style="Section.TLabel").pack(
            anchor="w", padx=4, pady=(2, 0))
        self.scroll = _ScrollFrame(self)
        self.scroll.pack(fill="both", expand=True, padx=2, pady=2)
        self._rows: Dict[str, Dict[str, Any]] = {}
        self.refresh()

    # -- build / rebuild ----------------------------------------------------
    def refresh(self):
        inner = self.scroll.inner
        for child in inner.winfo_children():
            child.destroy()
        self._rows.clear()
        for blk in self.engine.block_chain():
            self._build_row(inner, blk)

    def _build_row(self, parent, blk) -> None:
        key = blk.key
        outer = ttk.Frame(parent, style="Card.TFrame")
        outer.pack(fill="x", expand=True, padx=2, pady=2)

        head = ttk.Frame(outer, style="Card.TFrame")
        head.pack(fill="x")

        var = tk.BooleanVar(value=bool(blk.enabled))
        cb = ttk.Checkbutton(head, text=blk.label, variable=var,
                             style="Card.TCheckbutton",
                             command=lambda k=key, v=var: self._toggle(k, v.get()))
        cb.pack(side="left", padx=4, pady=2)

        ttk.Button(head, text="\u25b2", width=2, style="Mini.TButton",
                   command=lambda k=key: self._move(k, -1)).pack(side="right")
        ttk.Button(head, text="\u25bc", width=2, style="Mini.TButton",
                   command=lambda k=key: self._move(k, +1)).pack(side="right")

        st = blk.status()
        if st:
            ttk.Label(head, text=st, style="Dim.TLabel").pack(side="left", padx=6)

        params_frame = ttk.Frame(outer, style="Card.TFrame")
        params_frame.pack(fill="x", padx=8, pady=(0, 4))
        fields = {}
        for spec in blk.param_specs():
            integer = float(spec["step"]).is_integer() and spec["hi"] <= 64
            fld = _NumericField(
                params_frame, spec["label"], spec["lo"], spec["hi"],
                blk._params.get(spec["name"], spec["default"]),
                spec["step"], spec["fmt"],
                lambda v, k=key, n=spec["name"]: self._set_param(k, n, v),
                integer=integer)
            fld.pack(fill="x", pady=1)
            fields[spec["name"]] = fld

        self._rows[key] = {"var": var, "frame": outer, "fields": fields}

    # -- callbacks ----------------------------------------------------------
    def _toggle(self, key: str, enabled: bool):
        self.engine.set_block_enabled(key, enabled)
        self.on_log("[chain] %s %s" % (key, "enabled" if enabled else "disabled"))

    def _move(self, key: str, delta: int):
        self.engine.move_block(key, delta)
        self.refresh()

    def _set_param(self, key: str, name: str, value: float):
        self.engine.set_block_param(key, name, value)


# ---------------------------------------------------------------------------
#  Main application
# ---------------------------------------------------------------------------

class Elite2KApp(tk.Tk):
    """The Elite2K console."""

    TICK_MS = 40            # ~25 fps for spectrum/scope
    WF_EVERY = 4            # waterfall every 4th tick (~6 fps)

    def __init__(self, profile: Optional[config.AppProfile] = None,
                 simulate: bool = False):
        super().__init__()
        self.withdraw()
        self.title(config.WINDOW_TITLE)
        self.geometry("1400x900")
        self.minsize(1080, 680)
        self.configure(bg=config.THEME["bg"])

        self.profile = profile or config.apply_preset("Balanced (recommended)")
        self._log_q: "queue.Queue[str]" = queue.Queue()
        self.engine = Engine(self.profile, on_log=self._log_q.put,
                             on_source_done=lambda: self._log_q.put(
                                 "[source] playback finished"))
        self._tick = 0
        self._ticks_since_wf = 0
        self._sink_note = ""
        self._synth_thread: Optional[threading.Thread] = None

        self._init_style()
        self._build_layout()
        self._sync_from_profile()
        self._drain_queue()
        self._schedule()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        avail = sink_mod.backend_availability()
        self.log("Elite2K %s ready -- backend: %s" % (config.VERSION, self.profile.backend))
        self.log("available: " + ", ".join(
            "%s=%s" % (k, "yes" if v else "no")
            for k, v in avail.items() if isinstance(v, bool)))

        self.deiconify()
        if simulate:
            self.after(600, self._start)

    # -- styling ------------------------------------------------------------
    def _init_style(self):
        T = config.THEME
        F = config.THEME_FONTS
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(".", background=T["bg"], foreground=T["fg"],
                        fieldbackground=T["panel_alt"], font=F["ui"])
        style.configure("TFrame", background=T["bg"])
        style.configure("Card.TFrame", background=T["panel"])
        style.configure("TLabel", background=T["bg"], foreground=T["fg"], font=F["ui"])
        style.configure("Field.TLabel", background=T["panel"], foreground=T["fg_dim"],
                        font=F["mono_small"])
        style.configure("Value.TLabel", background=T["panel"], foreground=T["accent"],
                        font=F["mono_small"])
        style.configure("Dim.TLabel", background=T["panel"], foreground=T["fg_dim"],
                        font=F["mono_small"])
        style.configure("Section.TLabel", background=T["bg"], foreground=T["accent2"],
                        font=F["section"])
        style.configure("Title.TLabel", background=T["bg"], foreground=T["fg"],
                        font=F["title"])
        style.configure("Card.TCheckbutton", background=T["panel"], foreground=T["fg"],
                        font=F["ui_bold"])
        style.map("Card.TCheckbutton", background=[("active", T["panel_alt"])])
        style.configure("TButton", background=T["panel_alt"], foreground=T["fg"],
                        font=F["ui"], borderwidth=0, padding=4)
        style.map("TButton", background=[("active", T["accent"])])
        style.configure("Mini.TButton", padding=1, font=F["mono_small"])
        style.configure("Accent.TButton", background=T["accent"], foreground="#ffffff",
                        font=F["ui_bold"])
        style.map("Accent.TButton", background=[("active", T["accent2"])])
        style.configure("Danger.TButton", background=T["danger"], foreground="#ffffff",
                        font=F["ui_bold"])
        style.configure("TCombobox", fieldbackground=T["panel_alt"], background=T["panel_alt"],
                        foreground=T["fg"])
        style.configure("TEntry", fieldbackground=T["panel_alt"], foreground=T["fg"])
        style.configure("Horizontal.TScale", background=T["panel"], troughcolor=T["panel_alt"])
        style.configure("Vertical.TScrollbar", background=T["panel_alt"],
                        troughcolor=T["bg"], borderwidth=0)

    # -- layout -------------------------------------------------------------
    def _build_layout(self):
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True)
        self._build_toolbar(root)

        body = ttk.Panedwindow(root, orient="horizontal")
        body.pack(fill="both", expand=True)

        left = ttk.Frame(body, width=330)
        centre = ttk.Frame(body)
        right = ttk.Frame(body, width=360)
        body.add(left, weight=0)
        body.add(centre, weight=4)
        body.add(right, weight=0)

        self._build_left(left)
        self._build_centre(centre)
        self._build_right(right)
        self._build_status(root)

    def _build_toolbar(self, root):
        bar = ttk.Frame(root, style="Card.TFrame")
        bar.pack(fill="x")
        ttk.Label(bar, text=" ELITE2K ", style="Title.TLabel").pack(side="left", padx=6)

        ttk.Label(bar, text="preset", style="Dim.TLabel",
                  ).pack(side="left", padx=(12, 2))
        self.preset_var = tk.StringVar(value="Balanced (recommended)")
        combo = ttk.Combobox(bar, textvariable=self.preset_var, width=24, state="readonly",
                             values=list(config.PRESETS.keys()))
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self._load_preset())

        self.start_btn = ttk.Button(bar, text="\u25b6 START", style="Accent.TButton",
                                    command=self._start)
        self.start_btn.pack(side="left", padx=8)
        self.stop_btn = ttk.Button(bar, text="\u25a0 STOP", style="Danger.TButton",
                                   command=self._stop, state="disabled")
        self.stop_btn.pack(side="left")
        ttk.Button(bar, text="\u23f8 PAUSE", command=self._pause).pack(side="left", padx=4)

        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(bar, text="Save profile", command=self._save_profile).pack(side="left")
        ttk.Button(bar, text="Load profile", command=self._load_profile).pack(side="left", padx=4)

    def _build_left(self, parent):
        scroll = _ScrollFrame(parent)
        scroll.pack(fill="both", expand=True)
        p = scroll.inner

        # -- RF -------------------------------------------------------------
        ttk.Label(p, text="RF CONFIGURATION", style="Section.TLabel").pack(
            anchor="w", padx=6, pady=(6, 2))

        ttk.Label(p, text="Band preset", style="Field.TLabel").pack(anchor="w", padx=6)
        self.band_var = tk.StringVar()
        band = ttk.Combobox(p, textvariable=self.band_var, state="readonly",
                            values=[b["name"] for b in config.BAND_PRESETS])
        band.pack(fill="x", padx=6)
        band.bind("<<ComboboxSelected>>", lambda _e: self._pick_band())

        ttk.Label(p, text="Centre frequency (Hz)", style="Field.TLabel").pack(
            anchor="w", padx=6, pady=(4, 0))
        self.freq_var = tk.StringVar()
        e = ttk.Entry(p, textvariable=self.freq_var)
        e.pack(fill="x", padx=6)
        e.bind("<Return>", lambda _e: self._apply_freq())
        e.bind("<FocusOut>", lambda _e: self._apply_freq())

        self.iq_field = _NumericField(
            p, "IQ sample rate", config.MIN_IQ_RATE, config.MAX_IQ_RATE,
            float(self.profile.rf.iq_rate), 100_000.0, "{:.0f}",
            lambda v: self._rf_set("iq_rate", int(round(v))), integer=True)
        self.iq_field.pack(fill="x", padx=6, pady=3)
        self.amp_field = _NumericField(
            p, "Baseband drive", 0.0, 1.0, self.profile.rf.tx_amplitude,
            0.01, "{:.2f}", lambda v: self._rf_set("tx_amplitude", v))
        self.amp_field.pack(fill="x", padx=6, pady=3)
        self.gain_field = _NumericField(
            p, "RF gain (dB)", 0.0, 62.0, self.profile.rf.rf_gain_db,
            1.0, "{:.0f}", lambda v: self._rf_set("rf_gain_db", v))
        self.gain_field.pack(fill="x", padx=6, pady=3)
        self.if_field = _NumericField(
            p, "IF gain (dB)", 0.0, 62.0, self.profile.rf.if_gain_db,
            1.0, "{:.0f}", lambda v: self._rf_set("if_gain_db", v))
        self.if_field.pack(fill="x", padx=6, pady=3)
        self.bb_field = _NumericField(
            p, "BB gain (dB)", 0.0, 62.0, self.profile.rf.bb_gain_db,
            1.0, "{:.0f}", lambda v: self._rf_set("bb_gain_db", v))
        self.bb_field.pack(fill="x", padx=6, pady=3)

        self.realtime_var = tk.BooleanVar(value=self.profile.realtime)
        ttk.Checkbutton(p, text="Realtime pacing", variable=self.realtime_var,
                        style="Card.TCheckbutton",
                        command=lambda: setattr(self.profile, "realtime",
                                                self.realtime_var.get())
                        ).pack(anchor="w", padx=6, pady=2)

        # -- source ---------------------------------------------------------
        ttk.Separator(p, orient="horizontal").pack(fill="x", padx=6, pady=6)
        ttk.Label(p, text="SOURCE", style="Section.TLabel").pack(anchor="w", padx=6)
        self.src_var = tk.StringVar(value=self.profile.source.kind)
        for kind, label in (("tone", "Tone generator"), ("noise", "White noise"),
                            ("mic", "Microphone"), ("tts", "Speech (TTS)"),
                            ("silence", "Silence")):
            ttk.Radiobutton(p, text=label, value=kind, variable=self.src_var,
                            command=self._apply_source).pack(anchor="w", padx=10)

        self.tone_field = _NumericField(
            p, "Tone frequency (Hz)", 20.0, 20000.0, self.profile.source.tone_hz,
            5.0, "{:.0f}", lambda v: self._src_set("tone_hz", v))
        self.tone_field.pack(fill="x", padx=6, pady=3)

        ttk.Label(p, text="TTS text", style="Field.TLabel").pack(anchor="w", padx=6,
                                                                  pady=(6, 0))
        self.tts_text = tk.Text(p, height=3, bg=config.THEME["panel_alt"],
                                fg=config.THEME["fg"], insertbackground=config.THEME["fg"],
                                relief="flat", font=config.THEME_FONTS["ui"],
                                wrap="word")
        self.tts_text.insert("1.0", self.profile.source.tts_text)
        self.tts_text.pack(fill="x", padx=6)

        row = ttk.Frame(p)
        row.pack(fill="x", padx=6, pady=3)
        ttk.Label(row, text="Voice", style="Field.TLabel").pack(side="left")
        self.voice_var = tk.StringVar(value=self.profile.source.tts_voice)
        ttk.Combobox(row, textvariable=self.voice_var, width=8, state="readonly",
                     values=["en", "en-us", "en-gb", "de", "fr", "es", "it", "pt",
                             "ru", "pl", "nl", "sv", "cs", "tr", "hi", "zh", "ja",
                             "ko"]).pack(side="left", padx=4)

        self.speed_field = _NumericField(
            p, "TTS speed (wpm)", 60.0, 400.0, float(self.profile.source.tts_speed),
            5.0, "{:.0f}", lambda v: self._src_set("tts_speed", int(round(v))),
            integer=True)
        self.speed_field.pack(fill="x", padx=6, pady=3)
        self.pitch_field = _NumericField(
            p, "TTS pitch", 0.0, 99.0, float(self.profile.source.tts_pitch),
            1.0, "{:.0f}", lambda v: self._src_set("tts_pitch", int(round(v))),
            integer=True)
        self.pitch_field.pack(fill="x", padx=6, pady=3)

        self.loop_var = tk.BooleanVar(value=self.profile.source.loop_buffer)
        ttk.Checkbutton(p, text="Loop TTS buffer", variable=self.loop_var,
                        style="Card.TCheckbutton").pack(anchor="w", padx=6)

        ttk.Button(p, text="Synthesize & load speech", style="Accent.TButton",
                   command=self._synthesize).pack(fill="x", padx=6, pady=6)

        # -- backend --------------------------------------------------------
        ttk.Separator(p, orient="horizontal").pack(fill="x", padx=6, pady=6)
        ttk.Label(p, text="OUTPUT BACK-END", style="Section.TLabel").pack(anchor="w", padx=6)
        self.back_var = tk.StringVar(value=self.profile.backend)
        self.back_labels = {m["key"]: m["label"] for m in config.BACKEND_MODES}
        ttk.Combobox(p, textvariable=self.back_var, state="readonly",
                     values=[self.back_labels[m["key"]] for m in config.BACKEND_MODES]
                     ).pack(fill="x", padx=6)
        self.back_var.trace_add("write", lambda *_: self._apply_backend())

        avail = sink_mod.backend_availability()
        txt = "  ".join("%s:%s" % (k, "\u2713" if avail.get(k) else "\u2717")
                        for k in ("hackrf", "soapy", "gnuradio", "audio"))
        ttk.Label(p, text=txt, style="Dim.TLabel").pack(anchor="w", padx=6, pady=(2, 0))

        ttk.Label(p, text="Back-end target (file / device)", style="Field.TLabel").pack(
            anchor="w", padx=6, pady=(4, 0))
        self.target_var = tk.StringVar(value=self.profile.backend_target)
        ttk.Entry(p, textvariable=self.target_var).pack(fill="x", padx=6)

    def _build_centre(self, parent):
        self.spectrum = SpectrumView(parent)
        self.spectrum.pack(fill="both", expand=True, padx=4, pady=(4, 0))
        self.waterfall = WaterfallView(parent)
        self.waterfall.pack(fill="both", expand=True, padx=4, pady=(4, 0))
        self.scope = ScopeView(parent)
        self.scope.pack(fill="x", expand=False, padx=4, pady=(4, 4))

    def _build_right(self, parent):
        nb = ttk.Notebook(parent)
        nb.pack(fill="both", expand=True, padx=4, pady=4)

        chain_tab = ttk.Frame(nb)
        nb.add(chain_tab, text="Chain")
        self.chain = ChainEditor(chain_tab, self.engine, self.log)
        self.chain.pack(fill="both", expand=True)

        metrics_tab = ttk.Frame(nb)
        nb.add(metrics_tab, text="Metrics")
        self._build_metrics(metrics_tab)

        log_tab = ttk.Frame(nb)
        nb.add(log_tab, text="Log")
        self.log_text = tk.Text(log_tab, bg=config.THEME["panel"], fg=config.THEME["fg"],
                                insertbackground=config.THEME["fg"], relief="flat",
                                font=config.THEME_FONTS["mono_small"], wrap="none")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")

    def _build_metrics(self, parent):
        self.metric_vars: Dict[str, tk.StringVar] = {}
        keys = [
            ("state", "State"), ("backend", "Back-end"),
            ("working_rate", "Working rate"), ("iq_rate", "IQ rate"),
            ("audio_rms", "Audio RMS"), ("audio_peak", "Audio peak"),
            ("drive_rms", "Drive RMS"), ("drive_duty", "Drive duty"),
            ("zcr_hz", "Zero-cross rate"), ("pulses_session", "Pulses"),
            ("iq_rms", "IQ RMS"), ("iq_peak", "IQ peak"),
            ("crest_db", "Crest factor"), ("throughput_ksps", "Throughput"),
            ("elapsed_s", "Elapsed"), ("iq_samples", "IQ samples"),
            ("energy_per_pulse_mj", "Energy/pulse"), ("peak_power_w", "Peak power"),
            ("error", "Error"),
        ]
        body = ttk.Frame(parent)
        body.pack(fill="both", expand=True, padx=8, pady=8)
        for i, (key, label) in enumerate(keys):
            ttk.Label(body, text=label, style="Field.TLabel").grid(
                row=i, column=0, sticky="w", pady=2)
            var = tk.StringVar(value="-")
            ttk.Label(body, textvariable=var, style="Value.TLabel").grid(
                row=i, column=1, sticky="e", padx=8, pady=2)
            self.metric_vars[key] = var
        body.columnconfigure(1, weight=1)

    def _build_status(self, root):
        bar = ttk.Frame(root, style="Card.TFrame")
        bar.pack(fill="x", side="bottom")
        self.status_var = tk.StringVar(value="idle")
        ttk.Label(bar, textvariable=self.status_var, style="Dim.TLabel").pack(
            side="left", padx=8, pady=2)
        ttk.Label(bar, text="upstream: " + config.UPSTREAM, style="Dim.TLabel").pack(
            side="right", padx=8)

    # -- profile sync -------------------------------------------------------
    def _sync_from_profile(self):
        rf = self.profile.rf
        self.freq_var.set("%.0f" % rf.frequency_hz)
        self.band_var.set(self._band_name_for(rf.frequency_hz))
        self.iq_field.set_value(rf.iq_rate)
        self.amp_field.set_value(rf.tx_amplitude)
        self.gain_field.set_value(rf.rf_gain_db)
        self.if_field.set_value(rf.if_gain_db)
        self.bb_field.set_value(rf.bb_gain_db)
        self.tone_field.set_value(self.profile.source.tone_hz)
        self.speed_field.set_value(self.profile.source.tts_speed)
        self.pitch_field.set_value(self.profile.source.tts_pitch)
        self.target_var.set(self.profile.backend_target)
        self.preset_var.set(self.profile.name if self.profile.name in config.PRESETS
                            else self.preset_var.get())

    def _band_name_for(self, hz: float) -> str:
        for b in config.BAND_PRESETS:
            if b["hz"] is not None and abs(b["hz"] - hz) < 1.0:
                return b["name"]
        return "Custom"

    # -- RF / source callbacks ---------------------------------------------
    def _pick_band(self):
        name = self.band_var.get()
        for b in config.BAND_PRESETS:
            if b["name"] == name and b["hz"] is not None:
                self.profile.rf.frequency_hz = float(b["hz"])
                self.freq_var.set("%.0f" % b["hz"])
                self.log("[rf] band %s -> %.3f MHz" % (name, b["hz"] / 1e6))
                return

    def _apply_freq(self):
        try:
            hz = float(self.freq_var.get().strip())
        except ValueError:
            self.freq_var.set("%.0f" % self.profile.rf.frequency_hz)
            return
        self.profile.rf.frequency_hz = hz
        self.band_var.set(self._band_name_for(hz))

    def _rf_set(self, attr: str, value):
        setattr(self.profile.rf, attr, value)
        self.profile.rf.clamped()

    def _src_set(self, attr: str, value):
        setattr(self.profile.source, attr, value)

    def _apply_source(self):
        self.profile.source.kind = self.src_var.get()
        self.engine.apply_profile(self.profile)
        self.log("[source] %s" % self.src_var.get())
        if self.src_var.get() == "mic":
            from ..backend.sources import MicrophoneSource
            if not MicrophoneSource.available():
                self.log("[source] microphone backend unavailable on this host")

    def _apply_backend(self):
        label = self.back_var.get()
        for key, lab in self.back_labels.items():
            if lab == label:
                self.profile.backend = key
                break

    # -- transport ----------------------------------------------------------
    def _start(self):
        self.profile.source.kind = self.src_var.get()
        self.profile.source.tone_hz = float(self.tone_field._var.get())
        self.profile.backend_target = self.target_var.get().strip()
        self.profile.realtime = bool(self.realtime_var.get())
        self._apply_freq()
        if self.profile.backend == "iqfile" and not self.profile.backend_target:
            self.profile.backend_target = os.path.join(os.getcwd(), "elite2k.iq")
            self.target_var.set(self.profile.backend_target)
        self.engine.apply_profile(self.profile)
        self.chain.refresh()
        try:
            self.engine.start()
        except Exception as exc:
            messagebox.showerror("Elite2K", "failed to start: %s" % exc)
            return
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_var.set("running: %s" % self.engine.sink.info())

    def _stop(self):
        try:
            self.engine.stop()
        except Exception:
            pass
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_var.set("stopped")

    def _pause(self):
        p = self.engine.toggle_pause()
        self.status_var.set("paused" if p else "running")

    def _load_preset(self):
        name = self.preset_var.get()
        self.profile = config.apply_preset(name)
        self.engine.apply_profile(self.profile)
        self._sync_from_profile()
        self.chain.refresh()
        self.log("[preset] %s loaded" % name)

    # -- TTS ----------------------------------------------------------------
    def _synthesize(self):
        if self._synth_thread is not None and self._synth_thread.is_alive():
            self.log("[tts] synthesis already in progress")
            return
        text = self.tts_text.get("1.0", "end").strip()
        voice = self.voice_var.get()
        speed = int(round(self.speed_field._var.get()))
        pitch = int(round(self.pitch_field._var.get()))
        loop = bool(self.loop_var.get())
        self.log("[tts] synthesizing %d chars (%s)..." % (len(text), voice))

        def worker():
            try:
                samples, engine_label = tts_mod.synthesize(
                    text, voice=voice, speed=speed, pitch=pitch)
                if samples.size == 0:
                    self._log_q.put("[tts] empty text")
                    return
                ms = tts_mod.active_region_ms(samples)
                self.engine.set_tts_buffer(samples, loop=loop,
                                           label="tts/%s" % engine_label)
                self._log_q.put("[tts] %s: %.2fs active (%.0f ms), %s"
                                % (engine_label, samples.size / config.AUDIO_RATE,
                                   ms, "loop" if loop else "once"))
                self._log_q.put("__tts_loaded__")
            except Exception as exc:
                self._log_q.put("[tts] error: %s" % exc)

        self._synth_thread = threading.Thread(target=worker, daemon=True)
        self._synth_thread.start()

    # -- profiles -----------------------------------------------------------
    def _save_profile(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=[("Elite2K profile", "*.json")],
            initialfile="%s.json" % self.profile.name.replace(" ", "_").lower())
        if not path:
            return
        self.profile.name = os.path.splitext(os.path.basename(path))[0]
        try:
            self.profile.save(path)
            self.log("[profile] saved %s" % path)
        except Exception as exc:
            messagebox.showerror("Elite2K", "save failed: %s" % exc)

    def _load_profile(self):
        path = filedialog.askopenfilename(
            filetypes=[("Elite2K profile", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            prof = config.AppProfile.load(path)
        except Exception as exc:
            messagebox.showerror("Elite2K", "load failed: %s" % exc)
            return
        self.profile = prof
        self.engine.apply_profile(prof)
        self._sync_from_profile()
        self.chain.refresh()
        self.log("[profile] loaded %s" % path)

    # -- periodic refresh ---------------------------------------------------
    def _schedule(self):
        self.after(self.TICK_MS, self._tick_fn)

    def _tick_fn(self):
        self._tick += 1
        try:
            snap = self.engine.snapshot()
        except Exception:
            snap = None
        if snap:
            self.spectrum.update_data(snap["spectrum_db"], snap["spectrum_rate"])
            self.scope.update_data(snap["scope"])
            self._ticks_since_wf += 1
            if self._ticks_since_wf >= self.WF_EVERY:
                self._ticks_since_wf = 0
                self.waterfall.set_rows(snap["waterfall"])
                self.waterfall.render()
            self._update_metrics(snap["metrics"], snap["sink"], snap["paused"])
        self._drain_queue()
        self._schedule()

    def _update_metrics(self, m, sink_info: str, paused: bool):
        v = self.metric_vars
        state = "paused" if paused else ("running" if m.running else "idle")
        if m.error:
            state = "ERROR"
        v["state"].set(state)
        v["backend"].set(sink_info)
        v["working_rate"].set("%.1f kHz" % (m.working_rate / 1000.0))
        v["iq_rate"].set("%.3f MS/s" % (self.profile.rf.iq_rate / 1e6))
        v["audio_rms"].set("%.4f" % m.audio_rms)
        v["audio_peak"].set("%.4f" % m.audio_peak)
        v["drive_rms"].set("%.4f" % m.drive_rms)
        v["drive_duty"].set("%.3f" % m.drive_duty)
        v["zcr_hz"].set("%.1f Hz" % m.zcr_hz)
        v["pulses_session"].set("%d" % m.pulses_session)
        v["iq_rms"].set("%.4f" % m.iq_rms)
        v["iq_peak"].set("%.4f" % m.iq_peak)
        v["crest_db"].set("%.2f dB" % m.crest_db)
        v["throughput_ksps"].set("%.1f ksps" % m.throughput_ksps)
        v["elapsed_s"].set("%.1f s" % m.elapsed_s)
        v["iq_samples"].set("%d" % m.iq_samples)
        v["energy_per_pulse_mj"].set("%.2f mJ" % m.energy_per_pulse_mj)
        v["peak_power_w"].set("%.1f W" % m.peak_power_w)
        v["error"].set(m.error or "-")

    def _drain_queue(self):
        while True:
            try:
                msg = self._log_q.get_nowait()
            except queue.Empty:
                break
            if msg == "__tts_loaded__":
                self.src_var.set("tts")
                continue
            self.log(msg)

    # -- logging ------------------------------------------------------------
    def log(self, msg: str):
        if not hasattr(self, "log_text"):
            return
        t = self.log_text
        t.configure(state="normal")
        t.insert("end", msg + "\n")
        t.see("end")
        t.configure(state="disabled")

    # -- shutdown -----------------------------------------------------------
    def _on_close(self):
        try:
            self.engine.stop()
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:
    argv = list(argv if argv is not None else [])
    simulate = "--simulate" in argv
    profile: Optional[config.AppProfile] = None
    for i, a in enumerate(argv):
        if a == "--profile" and i + 1 < len(argv):
            try:
                profile = config.AppProfile.load(argv[i + 1])
            except Exception as exc:
                print("Elite2K: could not load profile %s: %s" % (argv[i + 1], exc))
        if a == "--preset" and i + 1 < len(argv):
            profile = config.apply_preset(argv[i + 1])

    try:
        app = Elite2KApp(profile=profile, simulate=simulate)
    except tk.TclError as exc:
        print("Elite2K: no display available (%s)." % exc)
        print("Run head-less instead:  python3 Elite2K.py --selftest")
        return 2
    app.mainloop()
    return 0


if __name__ == "__main__":      # pragma: no cover
    raise SystemExit(main())
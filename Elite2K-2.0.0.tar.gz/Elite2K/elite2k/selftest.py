#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""
Elite2K -- head-less self-test.

Exercises the DSP core, every modulator scheme, the resampler, the TTS
front-end (including the pure-Python fallback synthesiser), profile
round-tripping and the output back-end factory -- all without a display or
any SDR hardware.  Returns a process exit code (0 = all green) so it can be
wired into CI::

    python3 Elite2K.py --selftest
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from typing import List, Tuple

import numpy as np

from . import config
from .dsp import blocks as block_mod
from .dsp.engine import Engine, LinearResampler
from .backend import sinks as sink_mod
from .backend import sources as source_mod
from .backend import tts as tts_mod


class _Report:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.lines: List[str] = []

    def check(self, name: str, ok: bool, detail: str = "") -> bool:
        mark = "PASS" if ok else "FAIL"
        if ok:
            self.passed += 1
        else:
            self.failed += 1
        line = "  [%s] %-46s %s" % (mark, name, detail)
        self.lines.append(line)
        print(line)
        return ok


# ---------------------------------------------------------------------------
#  Individual checks
# ---------------------------------------------------------------------------

def _check_blocks(rep: _Report) -> None:
    print("\n-- block library --")
    rep.check("registry populated",
              len(block_mod.BLOCK_CLASSES) == 17,
              "%d blocks" % len(block_mod.BLOCK_CLASSES))
    rng = np.random.default_rng(1234)
    x = (np.sin(2 * np.pi * 400 * np.arange(4800) / config.AUDIO_RATE)
         * 0.5).astype(np.float32)
    ok = True
    detail = []
    for key in block_mod.BLOCK_REGISTRY:
        try:
            blk = block_mod.make_block(key)
            blk.set_rate(config.AUDIO_RATE)
            y = blk.process(x.copy())
            if not np.all(np.isfinite(y)):
                ok = False
                detail.append("%s:NaN" % key)
            elif y.dtype != np.float32:
                detail.append("%s:dtype" % key)
        except Exception as exc:
            ok = False
            detail.append("%s:%s" % (key, exc))
    rep.check("all blocks stream finite output", ok, ",".join(detail) or "17/17 clean")


def _mag_db(taps: np.ndarray, freq: float,
            rate: float = config.AUDIO_RATE) -> float:
    """Magnitude response of a FIR kernel at one frequency, in dB."""
    n = 1 << 15
    mag = np.abs(np.fft.rfft(taps, n))
    axis = np.fft.rfftfreq(n, 1.0 / rate)
    return 20.0 * np.log10(max(float(mag[int(np.argmin(np.abs(axis - freq)))]), 1e-12))


def _check_filter_response(rep: _Report) -> None:
    """Pass-band flatness / stop-band depth of the auto-designed kernels.

    Guards a real regression: an earlier high-pass carried the preset's
    440 Hz tone at -6 dB because the tap count was not derived from the
    wanted transition width.  A filter that mangles the carrier is invisible
    to a "does it stream finite numbers" test, so assert the response.
    """
    print("\n-- filter response --")
    hp = block_mod.make_block("highpass")
    hp.set_rate(config.AUDIO_RATE)
    taps = hp._design()
    pass_db = _mag_db(taps, 440.0)
    stop_db = _mag_db(taps, 50.0)
    rep.check("high-pass flat at 440 Hz", abs(pass_db) < 0.5,
              "%.2f dB (%d taps)" % (pass_db, taps.size))
    rep.check("high-pass rejects 50 Hz", stop_db < -20.0, "%.2f dB" % stop_db)

    lp = block_mod.make_block("lowpass")
    lp.set_rate(config.AUDIO_RATE)
    lp.set_param("cutoff", 2300.0)
    ltaps = lp._design()
    cut_db = _mag_db(ltaps, 2300.0)
    top_db = _mag_db(ltaps, 4000.0)
    rep.check("low-pass -6 dB at cutoff", abs(cut_db + 6.0) < 1.5,
              "%.2f dB" % cut_db)
    rep.check("low-pass rejects 4 kHz", top_db < -60.0,
              "%.2f dB (%d taps)" % (top_db, ltaps.size))


#: Chunk sizes every block must be invariant to.  The engine happens to feed
#: 2400-sample blocks, but a block that is only correct for one chunk size is
#: a latent bug, and two real ones hid here: an RMS AGC whose gain followed
#: the chunk length, and an overlap-add gate that zero-padded its shortfall
#: (which slid the stream by up to a hop per call).  Both were invisible
#: until the same signal was fed in different splits, hence this check.
_SPLIT_SIZES = (24_000, 2_400, 1_200, 997, 256, 100)


def _check_streaming_split(rep: _Report) -> None:
    print("\n-- chunk-size independence --")
    n = 24_000
    t = np.arange(n) / config.AUDIO_RATE
    x = (0.6 * np.sin(2 * np.pi * 440 * t)
         + 0.05 * np.sin(2 * np.pi * 90 * t)).astype(np.float32)
    bad: List[str] = []
    worst = 0.0
    for key in block_mod.BLOCK_REGISTRY:
        ref: np.ndarray | None = None
        err = 0.0
        for size in _SPLIT_SIZES:
            blk = block_mod.make_block(key)
            blk.reset()
            blk.set_rate(config.AUDIO_RATE)
            parts = [blk.process(x[i:i + size]) for i in range(0, n, size)]
            y = (np.concatenate(parts) if parts
                 else np.zeros(0, dtype=np.float32))
            if y.size != n or not np.all(np.isfinite(y)):
                err = float("inf")
                break
            if ref is None:
                ref = y
            else:
                err = max(err, float(np.max(np.abs(ref - y))))
        if not np.isfinite(err) or err > 1e-5:
            bad.append("%s(%.1e)" % (key, err))
        if np.isfinite(err):
            worst = max(worst, err)
    rep.check("all blocks split-invariant", not bad,
              ",".join(bad) or "max dev %.1e across %s"
              % (worst, "/".join(str(s) for s in _SPLIT_SIZES)))


def _check_pulse_chain(rep: _Report) -> None:
    """Rectifier -> Schmitt -> zero-cross counter must count the carrier."""
    print("\n-- pulse chain --")
    t = np.arange(2400) / config.AUDIO_RATE
    x = (0.8 * np.sin(2 * np.pi * 440 * t)).astype(np.float32)

    rect = block_mod.make_block("hwrect")
    rect.set_rate(config.AUDIO_RATE)
    z = rect.process(x)
    rep.check("half-wave rectifier keeps a floor",
              float(z.min()) < 0.0 and float(z.max()) > 0.5,
              "min=%.3f max=%.3f" % (float(z.min()), float(z.max())))

    sch = block_mod.make_block("schmitt")
    sch.set_rate(config.AUDIO_RATE)
    q = sch.process(z)
    uniq = np.unique(q)
    rep.check("schmitt is bipolar", uniq.size == 2,
              "levels=%s edges=%d" % (uniq.tolist(), sch._edges))

    zc = block_mod.make_block("zcp")
    zc.set_rate(config.AUDIO_RATE)
    zc.process(q)
    per_s = zc._pulses / 0.05
    rep.check("zero-cross pulses track the tone", abs(per_s - 880.0) < 60.0,
              "%.0f pulses/s (expect 2 x 440 Hz)" % per_s)


def _check_modulators(rep: _Report) -> None:
    print("\n-- modulator schemes --")
    x = (np.sin(2 * np.pi * 300 * np.arange(2400) / config.AUDIO_RATE)
         * 0.6).astype(np.float32)
    for mode, meta in enumerate(config.MODULATION_MODES):
        blk = block_mod.make_block("modulator")
        blk.reset()
        blk.set_rate(config.AUDIO_RATE)
        blk.set_param("mode", float(mode))
        try:
            blk.set_param("carrier_hz", 8000.0)
        except Exception:
            pass
        y = blk.process(x.copy())
        ok = (y.size == x.size and np.all(np.isfinite(y)))
        rep.check("modulator: %s" % meta["key"], bool(ok),
                  "peak=%.3f" % (float(np.max(np.abs(y))) if y.size else 0.0))


def _check_resampler(rep: _Report) -> None:
    print("\n-- rate conversion --")
    rs = LinearResampler()
    x = (np.sin(2 * np.pi * 220 * np.arange(4800) / config.AUDIO_RATE)
         ).astype(np.float32)
    y = rs.process(x, config.AUDIO_RATE, float(config.DEFAULT_IQ_RATE))
    expected = int(round(x.size * config.DEFAULT_IQ_RATE / config.AUDIO_RATE))
    ok = y.size >= expected - 4 and np.all(np.isfinite(y))
    rep.check("48 kHz -> 2 MHz resample", ok,
              "in=%d out=%d expected~%d" % (x.size, y.size, expected))
    # continuity across chunk boundaries
    rs2 = LinearResampler()
    acc = []
    for i in range(4):
        seg = x[i * 1200:(i + 1) * 1200]
        acc.append(rs2.process(seg, config.AUDIO_RATE, float(config.DEFAULT_IQ_RATE)))
    total = sum(a.size for a in acc)
    rep.check("chunked resample continuity", abs(total - expected) < 16,
              "chunked=%d streamed=%d" % (total, expected))


def _check_engine(rep: _Report) -> None:
    print("\n-- engine (simulated back-end) --")
    prof = config.apply_preset("Balanced (recommended)")
    prof.realtime = False
    logs: List[str] = []
    eng = Engine(prof, on_log=logs.append)
    eng.start()
    deadline = time.time() + 4.0
    while time.time() < deadline:
        time.sleep(0.1)
        if eng.metrics.iq_samples > 0 and eng.metrics.chunks > 20:
            break
    snap = eng.snapshot()
    eng.stop()
    m = snap["metrics"]
    rep.check("engine produced IQ", m.iq_samples > 0, "%d samples" % m.iq_samples)
    rep.check("no runtime error", m.error == "", m.error or "-")
    rep.check("spectrum populated", snap["spectrum_db"].size >= 8,
              "bins=%d" % snap["spectrum_db"].size)
    rep.check("waterfall populated", len(snap["waterfall"]) > 0,
              "rows=%d" % len(snap["waterfall"]))
    rep.check("scope populated", snap["scope"].size > 0,
              "len=%d" % snap["scope"].size)
    rep.check("pulses counted", m.pulses_session > 0, "%d" % m.pulses_session)


def _check_tts(rep: _Report) -> None:
    print("\n-- speech front-end --")
    report = tts_mod.backend_report()
    samples, engine_label = tts_mod.synthesize("elite two kay", voice="en",
                                               speed=150, pitch=25)
    rep.check("synthesiser returned samples", samples.size > 0,
              "engine=%s samples=%d" % (engine_label, samples.size))
    rep.check("samples are float32", samples.dtype == np.float32, str(samples.dtype))
    rep.check("finite output", bool(np.all(np.isfinite(samples))),
              "peak=%.3f" % (float(np.max(np.abs(samples))) if samples.size else 0.0))
    ms = tts_mod.active_region_ms(samples)
    rep.check("active region measured", ms > 0.0, "%.0f ms" % ms)
    rep.check("backend report consistent", isinstance(report, dict),
              "fallback=%s" % report.get("fallback"))


def _check_sources(rep: _Report) -> None:
    print("\n-- sources --")
    for kind in ("tone", "noise", "silence"):
        src = source_mod.make_source(kind, config.AUDIO_RATE, tone_hz=440.0)
        y = src.read(1024)
        rep.check("source: %s" % kind,
                  y.size == 1024 and np.all(np.isfinite(y)), src.info())
    buf = (np.sin(2 * np.pi * 300 * np.arange(9600) / config.AUDIO_RATE)
           ).astype(np.float32)
    bs = source_mod.BufferSource(buf, loop=False)
    first = bs.read(1024)
    rep.check("buffer source reads", first.size == 1024, "%d consumed" % bs._pos
              if hasattr(bs, "_pos") else "")


def _check_sinks(rep: _Report) -> None:
    print("\n-- output back-ends --")
    avail = sink_mod.backend_availability()
    rep.check("availability probe", isinstance(avail, dict),
              "hackrf=%s soapy=%s gnuradio=%s audio=%s"
              % (avail.get("hackrf"), avail.get("soapy"),
                 avail.get("gnuradio"), avail.get("audio")))
    prof = config.apply_preset("Balanced (recommended)")
    prof.backend = "iqfile"
    tmpdir = tempfile.mkdtemp(prefix="elite2k-selftest-")
    base = os.path.join(tmpdir, "capture")
    prof.backend_target = base
    sink, note = sink_mod.open_sink(prof)
    rep.check("iqfile sink selected", isinstance(sink, sink_mod.IQFileSink),
              note or "direct")
    iq = (np.concatenate([np.ones(2048), -np.ones(2048)])
          * 0.1).astype(np.float32).astype(np.complex64)
    try:
        sink.write(iq)
        sink.close()
    except Exception as exc:
        rep.check("iqfile sink write", False, str(exc))
        return
    size = os.path.getsize(base + ".cfile") if os.path.exists(base + ".cfile") else 0
    rep.check("iqfile sink wrote capture", size == iq.size * 8,
              "%d bytes (expected %d)" % (size, iq.size * 8))
    rep.check("iqfile sidecar written", os.path.exists(base + ".json"),
              os.path.basename(base) + ".json")
    # simulated back-end always available
    prof.backend = "sim"
    sim, _note = sink_mod.open_sink(prof)
    sim.write(iq)
    rep.check("simulated sink accepts data", sim.samples_written == iq.size,
              "%d samples" % sim.samples_written)


def _check_profiles(rep: _Report) -> None:
    print("\n-- profiles --")
    for name in config.PRESETS:
        try:
            prof = config.apply_preset(name)
            prof.rf.clamped()
            rep.check("preset: %s" % name, True,
                      "backend=%s chain=%d" % (prof.backend, len(prof.chain.order)))
        except Exception as exc:
            rep.check("preset: %s" % name, False, str(exc))

    prof = config.apply_preset("Balanced (recommended)")
    prof.name = "roundtrip"
    prof.chain.enabled["notch"] = True
    prof.chain.params.setdefault("lowpass", {})["cutoff"] = 2500.0
    tmpdir = tempfile.mkdtemp(prefix="elite2k-selftest-")
    path = os.path.join(tmpdir, "profile.json")
    prof.save(path)
    back = config.AppProfile.load(path)
    ok = (back.name == "roundtrip"
          and back.chain.enabled.get("notch") is True
          and abs(back.chain.params["lowpass"]["cutoff"] - 2500.0) < 1e-6
          and back.rf.frequency_hz == prof.rf.frequency_hz)
    rep.check("profile save/load round-trip", ok, os.path.basename(path))


# ---------------------------------------------------------------------------
#  Entry point
# ---------------------------------------------------------------------------

def run(verbose: bool = True) -> int:
    print("=" * 68)
    print("Elite2K %s -- self-test" % config.VERSION)
    print("python %s | numpy %s" % (sys.version.split()[0], np.__version__))
    print("=" * 68)
    rep = _Report()
    for fn in (_check_blocks, _check_filter_response, _check_streaming_split,
               _check_pulse_chain, _check_modulators, _check_resampler,
               _check_engine, _check_tts, _check_sources, _check_sinks,
               _check_profiles):
        try:
            fn(rep)
        except Exception as exc:               # pragma: no cover
            rep.check(fn.__name__, False, "unhandled: %s" % exc)

    print("\n" + "=" * 68)
    print("RESULT: %d passed, %d failed" % (rep.passed, rep.failed))
    print("=" * 68)
    return 0 if rep.failed == 0 else 1


if __name__ == "__main__":        # pragma: no cover
    raise SystemExit(run())
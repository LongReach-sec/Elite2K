#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Elite2K -- audio/envelope input sources.

Every source implements ``read(n) -> np.ndarray[float32]`` and returns
exactly ``n`` samples (zero-padding when a finite buffer is exhausted).
Sources are cheap and thread-confined to the engine's worker thread.
"""

from __future__ import annotations

import math
import threading
from typing import Optional

import numpy as np


class Source:
    name = "source"

    def read(self, n: int) -> np.ndarray:            # pragma: no cover
        return np.zeros(n, dtype=np.float32)

    def reset(self) -> None:
        pass

    def info(self) -> str:
        return self.name


class SilenceSource(Source):
    name = "silence"

    def read(self, n: int) -> np.ndarray:
        return np.zeros(n, dtype=np.float32)


class ToneSource(Source):
    name = "tone"

    def __init__(self, freq: float = 440.0, rate: float = 48_000.0,
                 amplitude: float = 0.8):
        self.freq = float(freq)
        self.rate = float(rate)
        self.amplitude = float(amplitude)
        self._phase = 0.0

    def reset(self):
        self._phase = 0.0

    def read(self, n):
        t = (np.arange(n, dtype=np.float64) + self._phase)
        y = self.amplitude * np.sin(2.0 * math.pi * self.freq / self.rate * t)
        self._phase = (self._phase + n) % (self.rate / max(self.freq, 1e-6))
        return y.astype(np.float32)

    def info(self):
        return f"tone {self.freq:.0f} Hz"


class NoiseSource(Source):
    name = "noise"

    def __init__(self, amplitude: float = 0.2, seed: int = 0xE2):
        self.amplitude = float(amplitude)
        self._rng = np.random.default_rng(seed)

    def read(self, n):
        return (self._rng.standard_normal(n) * self.amplitude).astype(np.float32)

    def info(self):
        return "white noise"


class BufferSource(Source):
    """Plays a fixed float32 buffer, optionally looping.

    ``done`` flips True once a non-looping buffer has been fully consumed;
    the engine uses this to auto-stop a one-shot TTS transmission.
    """

    name = "buffer"

    def __init__(self, buffer: Optional[np.ndarray] = None, loop: bool = True):
        self._buf = np.asarray(buffer, dtype=np.float32) if buffer is not None \
            else np.zeros(0, dtype=np.float32)
        self.loop = bool(loop)
        self._pos = 0
        self._done = False

    def set_buffer(self, buffer: np.ndarray, loop: Optional[bool] = None):
        self._buf = np.asarray(buffer, dtype=np.float32)
        self._pos = 0
        self._done = False
        if loop is not None:
            self.loop = bool(loop)

    @property
    def done(self) -> bool:
        return self._done

    def reset(self):
        self._pos = 0
        self._done = False

    def read(self, n):
        buf = self._buf
        if buf.size == 0:
            return np.zeros(n, dtype=np.float32)
        out = np.empty(n, dtype=np.float32)
        filled = 0
        while filled < n:
            if self._pos >= buf.size:
                if self.loop and buf.size > 0:
                    self._pos = 0
                else:
                    self._done = True
                    out[filled:] = 0.0
                    return out
            take = min(n - filled, buf.size - self._pos)
            out[filled:filled + take] = buf[self._pos:self._pos + take]
            self._pos += take
            filled += take
        return out

    def info(self):
        dur = self._buf.size / 48_000.0
        return f"buffer {dur:.2f}s ({'loop' if self.loop else 'once'})"


class MicrophoneSource(Source):
    """Live capture via the optional ``sounddevice`` package.

    Elite2K degrades gracefully when neither ``sounddevice`` nor a capture
    device is present: :meth:`available` reports False and the engine falls
    back to a silent source instead of crashing.
    """

    name = "mic"

    def __init__(self, rate: float = 48_000.0, blocksize: int = 1024):
        self.rate = float(rate)
        self._stream = None
        self._lock = threading.Lock()
        self._buf = np.zeros(0, dtype=np.float32)
        self._error = ""

    @staticmethod
    def available() -> bool:
        try:
            import sounddevice  # noqa: F401
            return True
        except Exception:
            return False

    def start(self) -> bool:
        if not self.available():
            self._error = "sounddevice not installed"
            return False
        try:
            import sounddevice as sd

            def _cb(indata, frames, time_info, status):   # noqa: ANN001
                with self._lock:
                    self._buf = np.concatenate(
                        (self._buf, indata[:, 0].astype(np.float32)))

            self._stream = sd.InputStream(
                samplerate=int(self.rate), channels=1, dtype="float32",
                callback=_cb)
            self._stream.start()
            return True
        except Exception as exc:                         # pragma: no cover
            self._error = str(exc)
            return False

    def stop(self):
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        with self._lock:
            self._buf = np.zeros(0, dtype=np.float32)

    def read(self, n):
        with self._lock:
            have = self._buf
            self._buf = np.zeros(0, dtype=np.float32)
        if have.size >= n:
            out = have[:n].copy()
            with self._lock:
                self._buf = np.concatenate((have[n:], self._buf))
            return out
        out = np.zeros(n, dtype=np.float32)
        out[:have.size] = have
        return out

    def info(self):
        return "microphone" if self._stream is not None else self._error or "mic (idle)"


def make_source(kind: str, rate: float = 48_000.0, **kw) -> Source:
    kind = (kind or "silence").lower()
    if kind == "tone":
        return ToneSource(kw.get("tone_hz", 440.0), rate)
    if kind == "noise":
        return NoiseSource(kw.get("amplitude", 0.2))
    if kind == "mic":
        src = MicrophoneSource(rate)
        if not src.start():
            return SilenceSource()
        return src
    if kind == "silence":
        return SilenceSource()
    # "tts" and anything unknown start silent; the GUI/engine pushes the
    # synthesized buffer into a BufferSource separately.
    return SilenceSource()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Elite2K -- output back-ends.

A back-end accepts complex64 base-band IQ frames from the engine.  Several
transports are provided so Elite2K is useful with or without hardware:

``sim``       discard data, keep statistics (default; runs anywhere)
``iqfile``    capture interleaved IQ to ``.cfile`` (+ ``.wav`` + ``.json``)
``hackrf``    stream straight to ``hackrf_transfer`` via stdin (no GNU Radio)
``soapy``     stream via SoapySDR when the python bindings are installed
``gnuradio``  stream via gr-osmosdr when GNU Radio is installed
``audio``     play the real component through a sound card (optional)
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
import wave
from collections import deque
from typing import Any, Dict, Optional

import numpy as np


class Sink:
    name = "sink"

    def __init__(self) -> None:
        self._n = 0
        self._bytes = 0

    def open(self, profile: Any) -> bool:
        return True

    def write(self, iq: np.ndarray) -> None:        # pragma: no cover
        self._n += int(iq.size)
        self._bytes += int(iq.size) * 8

    def close(self) -> None:
        pass

    def info(self) -> str:
        return self.name

    @property
    def samples_written(self) -> int:
        return self._n


class SimulatedSink(Sink):
    name = "sim"


class IQFileSink(Sink):
    """Capture to ``.cfile`` (interleaved float32 I/Q) with JSON sidecar."""

    name = "iqfile"

    def __init__(self, base_path: str):
        super().__init__()
        self.base_path = base_path or os.path.join(os.getcwd(), "elite2k_capture")
        self._fh = None
        self._wav = None
        self._meta: Dict[str, Any] = {}

    def open(self, profile):
        root, ext = os.path.splitext(self.base_path)
        self.base_path = root
        os.makedirs(os.path.dirname(os.path.abspath(root)) or ".", exist_ok=True)
        self._fh = open(root + ".cfile", "wb")
        # parallel 16-bit real-part WAV for quick listening/inspection
        self._wav = wave.open(root + ".wav", "wb")
        self._wav.setnchannels(1)
        self._wav.setsampwidth(2)
        self._wav.setframerate(int(profile.rf.iq_rate))
        self._meta = {
            "format": "interleaved float32 IQ (I,Q,I,Q,...)",
            "cfile": root + ".cfile",
            "iq_rate": int(profile.rf.iq_rate),
            "center_freq_hz": float(profile.rf.frequency_hz),
            "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "app": "Elite2K",
        }
        return True

    def write(self, iq):
        if self._fh is None:
            return
        inter = np.empty(iq.size * 2, dtype=np.float32)
        inter[0::2] = iq.real
        inter[1::2] = iq.imag
        self._fh.write(inter.tobytes())
        if self._wav is not None:
            r = np.clip(iq.real, -1.0, 1.0) * 32767.0
            self._wav.writeframes(r.astype(np.int16).tobytes())
        super().write(iq)

    def close(self):
        if self._fh is not None:
            self._fh.flush()
            self._fh.close()
            self._fh = None
        if self._wav is not None:
            self._wav.close()
            self._wav = None
        try:
            with open(self.base_path + ".json", "w", encoding="utf-8") as fh:
                json.dump(self._meta, fh, indent=2)
        except OSError:
            pass

    def info(self):
        return f"file: {self.base_path}.cfile"


class HackrfSink(Sink):
    """Stream signed-8-bit IQ to ``hackrf_transfer`` over stdin.

    This is a hardware path that needs no GNU Radio: only the ``hackrf``
    package (which provides ``hackrf_transfer``).  ``-t -`` makes the tool
    read the IQ stream from standard input.
    """

    name = "hackrf"

    def __init__(self, profile):
        super().__init__()
        self._profile = profile
        self._proc: Optional[subprocess.Popen] = None
        self._error = ""

    @staticmethod
    def available() -> bool:
        return shutil.which("hackrf_transfer") is not None

    def open(self, profile):
        self._profile = profile
        exe = shutil.which("hackrf_transfer")
        if not exe:
            self._error = "hackrf_transfer not found (sudo apt install hackrf)"
            return False
        cmd = [
            exe, "-t", "-",
            "-f", str(int(profile.rf.frequency_hz)),
            "-s", str(int(profile.rf.iq_rate)),
            "-x", str(int(profile.rf.rf_gain_db)),
            "-a", "1",
        ]
        try:
            self._proc = subprocess.Popen(
                cmd, stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as exc:                          # pragma: no cover
            self._error = f"failed to launch hackrf_transfer: {exc}"
            return False
        return True

    def write(self, iq):
        if self._proc is None or self._proc.stdin is None:
            return
        try:
            i8 = np.empty(iq.size * 2, dtype=np.int8)
            i8[0::2] = np.clip(iq.real * 127.0, -128, 127).astype(np.int8)
            i8[1::2] = np.clip(iq.imag * 127.0, -128, 127).astype(np.int8)
            self._proc.stdin.write(i8.tobytes())
            super().write(iq)
        except (BrokenPipeError, OSError) as exc:       # pragma: no cover
            self._error = f"hackrf stream closed: {exc}"

    def close(self):
        if self._proc is not None:
            try:
                if self._proc.stdin:
                    self._proc.stdin.close()
                self._proc.wait(timeout=3)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
            self._proc = None

    def info(self):
        return self._error or "hackrf_transfer stream"


class SoapySink(Sink):
    name = "soapy"

    def __init__(self, profile):
        super().__init__()
        self._profile = profile
        self._dev = None
        self._stream = None
        self._error = ""

    @staticmethod
    def available() -> bool:
        try:
            import SoapySDR  # noqa: F401
            return True
        except Exception:
            return False

    def open(self, profile):
        self._profile = profile
        if not self.available():
            self._error = "SoapySDR python bindings not installed"
            return False
        try:
            import SoapySDR
            from SoapySDR import SOAPY_SDR_TX, SOAPY_SDR_CF32
            self._dev = SoapySDR.Device(profile.backend_target or {})
            self._dev.setSampleRate(SOAPY_SDR_TX, 0, profile.rf.iq_rate)
            self._dev.setFrequency(SOAPY_SDR_TX, 0, profile.rf.frequency_hz)
            if profile.rf.rf_gain_db:
                self._dev.setGain(SOAPY_SDR_TX, 0, profile.rf.rf_gain_db)
            self._stream = self._dev.setupStream(SOAPY_SDR_TX, SOAPY_SDR_CF32)
            self._dev.activateStream(self._stream)
            return True
        except Exception as exc:                        # pragma: no cover
            self._error = f"SoapySDR setup failed: {exc}"
            return False

    def write(self, iq):
        if self._dev is None or self._stream is None:
            return
        try:
            from SoapySDR import SOAPY_SDR_TX
            self._dev.writeStream(self._stream, [iq.astype(np.complex64)], iq.size)
            super().write(iq)
        except Exception as exc:                        # pragma: no cover
            self._error = f"SoapySDR write failed: {exc}"

    def close(self):
        if self._dev is not None and self._stream is not None:
            try:
                self._dev.deactivateStream(self._stream)
                self._dev.closeStream(self._stream)
            except Exception:
                pass
        self._dev = None
        self._stream = None

    def info(self):
        return self._error or "SoapySDR stream"


class GnuRadioSink(Sink):
    """Stream into a gr-osmosdr sink via a custom source block.

    Used only when GNU Radio and gr-osmosdr are importable; otherwise the
    engine reports the reason and falls back to the simulated sink.
    """

    name = "gnuradio"

    def __init__(self, profile):
        super().__init__()
        self._profile = profile
        self._tb = None
        self._queue: "deque[np.ndarray]" = deque()
        self._lock = threading.Lock()
        self._error = ""
        self._thread: Optional[threading.Thread] = None

    @staticmethod
    def available() -> bool:
        try:
            import gnuradio  # noqa: F401
            import osmosdr   # noqa: F401
            return True
        except Exception:
            return False

    def open(self, profile):
        self._profile = profile
        if not self.available():
            self._error = "GNU Radio / gr-osmosdr not installed"
            return False
        try:
            from gnuradio import gr, blocks
            import osmosdr

            outer = self

            class _Feeder(gr.sync_block):
                def __init__(self):
                    gr.sync_block.__init__(self, name="elite2k_feed",
                                           in_sig=None, out_sig=[np.complex64])

                def work(self, input_items, output_items):
                    out = output_items[0]
                    with outer._lock:
                        if not outer._queue:
                            return 0
                        chunk = outer._queue.popleft()
                    n = min(len(out), len(chunk))
                    out[:n] = chunk[:n]
                    if n < len(chunk):
                        with outer._lock:
                            outer._queue.appendleft(chunk[n:])
                    return n

            tb = gr.top_block()
            feeder = _Feeder()
            snk = osmosdr.sink(args=profile.backend_target or "hackrf=0")
            snk.set_sample_rate(profile.rf.iq_rate)
            snk.set_center_freq(profile.rf.frequency_hz, 0)
            snk.set_freq_corr(int(profile.rf.freq_correction_ppm), 0)
            snk.set_gain(profile.rf.rf_gain_db, 0)
            if profile.rf.if_gain_db:
                snk.set_if_gain(profile.rf.if_gain_db, 0)
            if profile.rf.bb_gain_db:
                snk.set_bb_gain(profile.rf.bb_gain_db, 0)
            tb.connect(feeder, snk)
            self._tb = tb
            self._feeder = feeder
            tb.start()
            return True
        except Exception as exc:                        # pragma: no cover
            self._error = f"GNU Radio setup failed: {exc}"
            return False

    def write(self, iq):
        if self._tb is None:
            return
        with self._lock:
            # bound the queue so a slow SDR cannot exhaust memory
            while len(self._queue) > 64:
                self._queue.popleft()
            self._queue.append(iq.astype(np.complex64))
        super().write(iq)

    def close(self):
        if self._tb is not None:
            try:
                self._tb.stop()
                self._tb.wait()
            except Exception:
                pass
            self._tb = None

    def info(self):
        return self._error or "gr-osmosdr stream"


class AudioSink(Sink):
    name = "audio"

    def __init__(self, profile):
        super().__init__()
        self._stream = None
        self._error = ""

    @staticmethod
    def available() -> bool:
        try:
            import sounddevice  # noqa: F401
            return True
        except Exception:
            return False

    def open(self, profile):
        if not self.available():
            self._error = "sounddevice not installed"
            return False
        try:
            import sounddevice as sd
            self._stream = sd.OutputStream(
                samplerate=int(min(profile.rf.iq_rate, 192_000)),
                channels=1, dtype="float32")
            self._stream.start()
            return True
        except Exception as exc:                        # pragma: no cover
            self._error = f"audio output failed: {exc}"
            return False

    def write(self, iq):
        if self._stream is None:
            return
        try:
            # decimate the real part down to the audio device rate
            r = iq.real
            step = max(1, int(round(self._profile.rf.iq_rate / 48_000)))
            self._stream.write(r[::step].astype(np.float32))
            super().write(iq)
        except Exception:                               # pragma: no cover
            pass

    def close(self):
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

    def info(self):
        return self._error or "audio output"


# ---------------------------------------------------------------------------
#  Factory
# ---------------------------------------------------------------------------

_BACKENDS = {
    "sim": lambda prof, target: SimulatedSink(),
    "iqfile": lambda prof, target: IQFileSink(target),
    "hackrf": lambda prof, target: HackrfSink(prof),
    "soapy": lambda prof, target: SoapySink(prof),
    "gnuradio": lambda prof, target: GnuRadioSink(prof),
    "audio": lambda prof, target: AudioSink(prof),
}


def backend_availability() -> Dict[str, Any]:
    """Report which transports can actually be used on this machine."""
    return {
        "sim": True,
        "iqfile": True,
        "hackrf": HackrfSink.available(),
        "soapy": SoapySink.available(),
        "gnuradio": GnuRadioSink.available(),
        "audio": AudioSink.available(),
        "hackrf_transfer": shutil.which("hackrf_transfer"),
        "gnuradio_present": GnuRadioSink.available(),
    }


def make_sink(profile) -> Sink:
    """Build the sink for ``profile.backend``.

    Returns ``(sink, ok, note)`` via :func:`open_sink`; this helper only
    constructs.  Prefer :func:`open_sink`.
    """
    factory = _BACKENDS.get(profile.backend, _BACKENDS["sim"])
    return factory(profile, profile.backend_target)


def open_sink(profile):
    """Construct and open the configured sink.

    Falls back to :class:`SimulatedSink` when the requested transport is
    unavailable, returning ``(sink, note)`` where ``note`` explains any
    substitution so the GUI can surface it truthfully.
    """
    sink = make_sink(profile)
    ok = False
    note = ""
    try:
        ok = sink.open(profile)
    except Exception as exc:
        ok = False
        note = f"{profile.backend} backend error: {exc}"
    if not ok:
        note = note or getattr(sink, "_error", "") or \
            f"{profile.backend} backend unavailable"
        try:
            sink.close()
        except Exception:
            pass
        fallback = SimulatedSink()
        fallback.open(profile)
        return fallback, note
    return sink, note
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Pluggable I/O back-ends: sources (audio in) and sinks (RF out)."""

from __future__ import annotations

from . import sinks, sources, tts
from .sinks import (
    Sink,
    SimulatedSink,
    IQFileSink,
    HackrfSink,
    SoapySink,
    GnuRadioSink,
    AudioSink,
    backend_availability,
    make_sink,
    open_sink,
)
from .sources import Source, make_source

__all__ = [
    "sinks",
    "sources",
    "tts",
    "Sink",
    "SimulatedSink",
    "IQFileSink",
    "HackrfSink",
    "SoapySink",
    "GnuRadioSink",
    "AudioSink",
    "backend_availability",
    "make_sink",
    "open_sink",
    "Source",
    "make_source",
]
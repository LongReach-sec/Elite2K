#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SPDX-License-Identifier: Unlicense
"""Elite2K -- text-to-speech with a dependency-free fallback.

Primary path uses ``espeak-ng``/``espeak`` if installed (optionally with the
MBROLA diphone voices, exactly like the upstream project).  When neither is
present -- as on a bare container -- :class:`FallbackSynth` renders the text
with an internal source-filter (formant) model so the tool still produces a
usable intelligible-ish envelope instead of failing.
"""

from __future__ import annotations

import math
import os
import re
import shutil
import subprocess
import tempfile
import wave
from typing import List, Optional, Tuple

import numpy as np

AUDIO_RATE = 48_000

# locale -> espeak voice (kept small; espeak-ng accepts any installed voice)
VOICE_MAP = {
    "en": "en", "en-us": "en-us", "en-gb": "en-gb", "de": "de", "fr": "fr",
    "es": "es", "it": "it", "pt": "pt", "ru": "ru", "nl": "nl", "pl": "pl",
    "sv": "sv", "fi": "fi", "tr": "tr", "hi": "hi", "ja": "ja", "ko": "ko",
    "zh": "cmn", "ar": "ar",
}

# MBROLA voice codes per locale (matches upstream OpenV2K's mapping style).
_MBROLA_VOICE_MAP = {
    "en": "en1", "de": "de6", "fr": "fr4", "es": "es1", "it": "it3",
    "pt": "pt1", "ru": "ru1", "nl": "nl2", "pl": "pl1", "sv": "sv1",
    "ro": "ro1", "hi": "hi1", "ja": "jp1", "ko": "ko1", "zh": "cn1",
    "ar": "ar1", "tr": "tr1", "el": "gr2",
}


# ---------------------------------------------------------------------------
#  Backend discovery
# ---------------------------------------------------------------------------

def espeak_binary() -> Optional[str]:
    for cmd in ("espeak-ng", "espeak"):
        path = shutil.which(cmd)
        if path:
            return path
    return None


def mbrola_binary() -> Optional[str]:
    path = shutil.which("mbrola")
    if not path:
        return None
    for p in ("/usr/share/mbrola/en1", "/usr/lib/mbrola/en1",
              "/usr/share/mbrola"):
        if os.path.exists(p):
            return "mbrola"
    return None


def mbrola_voice_code(locale: str) -> Optional[str]:
    return _MBROLA_VOICE_MAP.get((locale or "en").split("_")[0].lower())


def backend_report() -> dict:
    es = espeak_binary()
    mb = mbrola_binary()
    return {
        "espeak": es or "not found",
        "mbrola": mb or "not found",
        "fallback": "available (pure NumPy formant synth)",
        "uses": "espeak" if es else "fallback",
    }


# ---------------------------------------------------------------------------
#  Fallback formant synthesiser
# ---------------------------------------------------------------------------

class FallbackSynth:
    """Very small source-filter synthesizer.

    Text is chopped into vowel-ish atoms (phrases separated on whitespace);
    each atom receives a pitch contour, a glottal buzz and three formants.
    It is deliberately simple -- the goal is a broadband speech-like envelope
    that exercises the whole DSP chain without external tools.
    """

    # (F1, F2, F3) formant sets for a handful of vowels
    VOWELS = {
        "a": (800, 1150, 2900), "e": (400, 2000, 2550),
        "i": (350, 2200, 3000), "o": (450, 800, 2830),
        "u": (325, 700, 2530), "y": (300, 1900, 2500),
        "s": (900, 4000, 6000), "h": (500, 1500, 2500),
    }

    def __init__(self, rate: int = AUDIO_RATE):
        self.rate = rate

    def _vowel_for(self, ch: str) -> Tuple[float, float, float]:
        return self.VOWELS.get(ch.lower(), (500, 1500, 2500))

    def _buzz(self, n: int, f0: np.ndarray) -> np.ndarray:
        """Band-limited-ish pulse train driven by the F0 contour."""
        phase = np.cumsum(2.0 * math.pi * f0 / self.rate)
        # glottal-like pulse: raised cosine per period
        frac = np.mod(phase / (2.0 * math.pi), 1.0)
        pulse = 0.5 - 0.5 * np.cos(2.0 * math.pi * frac)
        return (pulse - pulse.mean()).astype(np.float64)

    def synthesize(self, text: str, speed: int = 130, pitch: int = 20) -> np.ndarray:
        words = re.findall(r"[A-Za-z]+", text) or ["eh"]
        base_f0 = 70.0 + 6.0 * max(0, min(100, pitch))       # ~70..130 Hz
        dur_per_char = 0.075 * (170.0 / max(40.0, float(speed)))
        out: List[np.ndarray] = []
        for w in words[:32]:
            for ch in w:
                dur = dur_per_char * (1.4 if ch.lower() in "aeiou" else 0.7)
                n = max(8, int(self.rate * dur))
                t = np.linspace(0.0, 1.0, n)
                f1, f2, f3 = self._vowel_for(ch)
                # gentle pitch contour: rise then fall over the segment
                f0 = base_f0 * (1.0 + 0.06 * np.sin(math.pi * t) - 0.04 * t)
                src = self._buzz(n, f0)
                # crude 3-formant resonance bank via additive shaping
                sig = np.zeros(n)
                for fc, amp in ((f1, 1.0), (f2, 0.6), (f3, 0.3)):
                    sig += amp * np.sin(2.0 * math.pi * fc * t) * (0.5 + 0.5 * np.sin(math.pi * t))
                sig *= src
                # consonant frication for non-vowels
                if ch.lower() not in "aeiou":
                    sig += 0.15 * np.random.default_rng(abs(hash((ch, len(out)))) % (2**31)).standard_normal(n) \
                        * np.exp(-4.0 * t)
                out.append(sig)
            out.append(np.zeros(int(self.rate * 0.05)))        # inter-word gap
        if not out:
            return np.zeros(0, dtype=np.float32)
        y = np.concatenate(out)
        peak = float(np.max(np.abs(y))) or 1.0
        y = (y / peak) * 0.85
        return y.astype(np.float32)


# ---------------------------------------------------------------------------
#  Public API
# ---------------------------------------------------------------------------

def synthesize(text: str, voice: str = "en", speed: int = 130, pitch: int = 20,
               use_mbrola: bool = False
               ) -> Tuple[np.ndarray, str]:
    """Return ``(samples_float32_48k, engine_label)``.

    ``engine_label`` is ``"espeak-ng"``/``"espeak"`` when the external tool
    was used, or ``"fallback"`` when the built-in synthesizer ran.
    """
    text = (text or "").strip()
    if not text:
        return np.zeros(0, dtype=np.float32), "empty"

    binary = espeak_binary()
    if binary:
        try:
            samples = _espeak_render(binary, text, voice, speed, pitch, use_mbrola)
            if samples is not None and samples.size > 0:
                return samples, os.path.basename(binary)
        except Exception:
            pass

    synth = FallbackSynth()
    return synth.synthesize(text, speed, pitch), "fallback"


def _espeak_render(binary: str, text: str, voice: str, speed: int, pitch: int,
                   use_mbrola: bool) -> Optional[np.ndarray]:
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as fh:
        raw_path = fh.name
    try:
        cmd = [binary]
        if use_mbrola:
            code = mbrola_voice_code(voice)
            if code:
                cmd += ["-v", f"mb-{code}", "-a", "200", "-s", str(speed)]
            else:
                cmd += ["-v", VOICE_MAP.get(voice, "en"), "-p", str(pitch),
                        "-s", str(speed)]
        else:
            cmd += ["-v", VOICE_MAP.get(voice, voice or "en"),
                    "-p", str(pitch), "-s", str(speed)]
        cmd += ["-w", raw_path, text]

        env = os.environ.copy()
        env.setdefault("MBROLA", "/usr/share/mbrola")
        res = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=20, env=env)
        if res.returncode != 0 or not os.path.exists(raw_path):
            return None
        if os.path.getsize(raw_path) < 44:
            return None
        with wave.open(raw_path, "r") as wf:
            sr = wf.getframerate()
            n_ch = wf.getnchannels()
            frames = wf.readframes(wf.getnframes())
        data = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
        if n_ch > 1:
            data = data.reshape(-1, n_ch).mean(axis=1)
        if sr != AUDIO_RATE and data.size > 1:
            n = int(round(data.size * AUDIO_RATE / sr))
            data = np.interp(np.linspace(0, data.size - 1, n),
                             np.arange(data.size), data).astype(np.float32)
        # 100 ms of silence each end, matching upstream's AGC behaviour
        pad = np.zeros(int(AUDIO_RATE * 0.1), dtype=np.float32)
        return np.concatenate((pad, data.astype(np.float32), pad))
    finally:
        try:
            os.unlink(raw_path)
        except OSError:
            pass


def active_region_ms(samples: np.ndarray, rate: int = AUDIO_RATE) -> float:
    """Duration of the above-5%-of-peak region, in milliseconds."""
    if samples.size == 0:
        return 0.0
    mag = np.abs(samples)
    thr = max(float(mag.max()) * 0.05, 1e-9)
    idx = np.where(mag > thr)[0]
    if idx.size == 0:
        return 0.0
    return (idx[-1] - idx[0]) / rate * 1000.0